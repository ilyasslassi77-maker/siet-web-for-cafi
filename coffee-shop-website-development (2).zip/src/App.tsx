import { useState } from 'react';
import { CoffeeProvider } from './context/CoffeeContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { BeansRoasterySection } from './components/BeansRoasterySection';
import { BrewCalculatorTimer } from './components/BrewCalculatorTimer';
import { StoryEthicalSection } from './components/StoryEthicalSection';
import { CafeExperience } from './components/CafeExperience';
import { LocationsFooter } from './components/LocationsFooter';
import { DrinkCustomizeModal } from './components/DrinkCustomizeModal';
import { CartDrawer } from './components/CartDrawer';
import { FlavorQuizModal } from './components/FlavorQuizModal';
import { TableReservationModal } from './components/TableReservationModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { Toast } from './components/Toast';

export function CoffeeApp() {
  const [searchQuery, setSearchQuery] = useState('');

  const focusSearch = () => {
    const el = document.getElementById('menu');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      // Focus search input
      setTimeout(() => {
        const input = document.querySelector('input[placeholder*="Search vanilla latte"]') as HTMLInputElement;
        if (input) input.focus();
      }, 500);
    }
  };

  return (
    <div className="min-h-screen bg-[#fbf7f2] text-[#2b1f17] flex flex-col selection:bg-[#c59b6d] selection:text-[#140e0a]">
      {/* Sticky Top Navbar */}
      <Navbar onSearchClick={focusSearch} activeSection="home" />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero />

        {/* Cafe Menu & Beverage Offerings */}
        <MenuSection searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

        {/* Roasted Beans & Bag Subscription */}
        <BeansRoasterySection />

        {/* Interactive Ratio Calculator & Live Brew Stopwatch */}
        <BrewCalculatorTimer />

        {/* Direct Trade Story & Ethical Roast */}
        <StoryEthicalSection />

        {/* Cafe Space & Testimonials */}
        <CafeExperience />
      </main>

      {/* Locations, Hours & Newsletter Footer */}
      <LocationsFooter />

      {/* Floating & Overlay Interactive Components */}
      <DrinkCustomizeModal />
      <CartDrawer />
      <FlavorQuizModal />
      <TableReservationModal />
      <OrderSuccessModal />
      <Toast />
    </div>
  );
}

export default function App() {
  return (
    <CoffeeProvider>
      <CoffeeApp />
    </CoffeeProvider>
  );
}
