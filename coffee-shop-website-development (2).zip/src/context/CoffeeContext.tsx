import React, { createContext, useContext, useState, useEffect } from 'react';
import { CoffeeItem, CartItem, CustomizationOptions, CoffeeBean } from '../types';

interface CoffeeContextType {
  cart: CartItem[];
  cartCount: number;
  cartSubtotal: number;
  addToCart: (item: CoffeeItem, options?: Partial<CustomizationOptions>, quantity?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, delta: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  
  // Customization modal
  customizingItem: CoffeeItem | null;
  openCustomizer: (item: CoffeeItem) => void;
  closeCustomizer: () => void;

  // Quiz modal
  isQuizOpen: boolean;
  setIsQuizOpen: (open: boolean) => void;

  // Reservation modal
  isReservationOpen: boolean;
  setIsReservationOpen: (open: boolean) => void;

  // Order confirmation modal
  activeOrder: {
    orderId: string;
    items: CartItem[];
    total: number;
    pickupTime: string;
    fulfillmentType: 'pickup' | 'delivery';
    address?: string;
  } | null;
  setActiveOrder: (order: any) => void;

  // Quick Bean bag addition
  addBeanToCart: (bean: CoffeeBean, grindSize: string, isSubscription: boolean) => void;

  // Notification toast
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const CoffeeContext = createContext<CoffeeContextType | undefined>(undefined);

export const CoffeeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('terra_coffee_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [customizingItem, setCustomizingItem] = useState<CoffeeItem | null>(null);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<any>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('terra_coffee_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 3200);
  };

  const openCustomizer = (item: CoffeeItem) => {
    setCustomizingItem(item);
  };

  const closeCustomizer = () => {
    setCustomizingItem(null);
  };

  const addToCart = (
    item: CoffeeItem,
    optionsPartial?: Partial<CustomizationOptions>,
    quantity = 1
  ) => {
    const defaultOptions: CustomizationOptions = {
      size: '12oz',
      temperature: item.category === 'cold-brew' ? 'Iced' : 'Hot',
      milk: 'Whole Milk',
      sweetness: '50% (Standard)',
      iceLevel: item.category === 'cold-brew' ? 'Regular Ice' : undefined,
      extras: [],
      notes: ''
    };

    const options: CustomizationOptions = { ...defaultOptions, ...optionsPartial };

    // Calculate unit price based on options
    let unitPrice = item.price;
    if (options.size === '16oz') unitPrice += 0.85;
    if (options.size === '8oz') unitPrice = Math.max(item.price - 0.40, 3.50);
    if (options.milk.includes('+0.75')) unitPrice += 0.75;
    if (options.extras.includes('Extra Double Shot')) unitPrice += 1.25;
    if (options.extras.includes('Madagascar Vanilla Bean')) unitPrice += 0.80;
    if (options.extras.includes('Salted Caramel Drizzle')) unitPrice += 0.65;
    if (options.extras.includes('Oat Cold Foam')) unitPrice += 1.20;

    const cartItemId = `${item.id}-${options.size}-${options.temperature}-${options.milk}-${options.extras.sort().join('_')}-${options.grindSize || ''}`;

    setCart(prev => {
      const existingIdx = prev.findIndex(ci => ci.cartItemId === cartItemId);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        return updated;
      } else {
        return [
          ...prev,
          {
            cartItemId,
            item,
            options,
            unitPrice: Number(unitPrice.toFixed(2)),
            quantity
          }
        ];
      }
    });

    showToast(`Added ${quantity}x "${item.name}" to your order`);
  };

  const addBeanToCart = (bean: CoffeeBean, grindSize: string, isSubscription: boolean) => {
    const discountedPrice = isSubscription ? Number((bean.price * 0.85).toFixed(2)) : bean.price;
    const pseudoItem: CoffeeItem = {
      id: bean.id,
      name: `${bean.name} (${bean.bagSize.split(' ')[0]})`,
      category: 'pour-over',
      price: discountedPrice,
      description: bean.description,
      image: bean.image,
      tags: [bean.origin, grindSize, isSubscription ? '15% Off Sub' : 'Whole Bag'],
      rating: bean.rating,
      reviewsCount: 88,
      flavorNotes: bean.tastingNotes,
      customizable: false
    };

    const cartItemId = `${bean.id}-${grindSize}-${isSubscription ? 'sub' : 'onetime'}`;

    setCart(prev => {
      const existingIdx = prev.findIndex(ci => ci.cartItemId === cartItemId);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += 1;
        return updated;
      }
      return [
        ...prev,
        {
          cartItemId,
          item: pseudoItem,
          options: {
            size: '12oz',
            temperature: 'Hot',
            milk: 'None (Black)',
            sweetness: '0% (Unsweetened)',
            extras: [],
            grindSize: `Grind: ${grindSize}${isSubscription ? ' (Monthly Subscription)' : ''}`
          },
          unitPrice: discountedPrice,
          quantity: 1
        }
      ];
    });

    showToast(`Added fresh roasted "${bean.name}" (${grindSize}) to order`);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.cartItemId !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(ci => {
          if (ci.cartItemId === cartItemId) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);
  const cartSubtotal = Number(cart.reduce((acc, curr) => acc + curr.unitPrice * curr.quantity, 0).toFixed(2));

  return (
    <CoffeeContext.Provider
      value={{
        cart,
        cartCount,
        cartSubtotal,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        customizingItem,
        openCustomizer,
        closeCustomizer,
        isQuizOpen,
        setIsQuizOpen,
        isReservationOpen,
        setIsReservationOpen,
        activeOrder,
        setActiveOrder,
        addBeanToCart,
        toastMessage,
        showToast
      }}
    >
      {children}
    </CoffeeContext.Provider>
  );
};

export const useCoffee = () => {
  const context = useContext(CoffeeContext);
  if (!context) {
    throw new Error('useCoffee must be used within a CoffeeProvider');
  }
  return context;
};
