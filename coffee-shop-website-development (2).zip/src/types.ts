export type ProductCategory = 
  | 'all' 
  | 'espresso' 
  | 'cold-brew' 
  | 'pour-over' 
  | 'signature' 
  | 'bakery';

export interface CoffeeItem {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  description: string;
  image: string;
  tags: string[];
  rating: number;
  reviewsCount: number;
  isPopular?: boolean;
  isNew?: boolean;
  calories?: number;
  roastLevel?: 'Light' | 'Medium' | 'Dark';
  origin?: string;
  flavorNotes: string[];
  customizable: boolean;
  caffeineMg?: number;
}

export interface CustomizationOptions {
  size: '8oz' | '12oz' | '16oz';
  temperature: 'Hot' | 'Iced';
  milk: 'Whole Milk' | 'Oat Milk (+0.75)' | 'Almond Milk (+0.75)' | 'Coconut Milk (+0.75)' | 'None (Black)';
  sweetness: '0% (Unsweetened)' | '25% (Hint of Sweet)' | '50% (Standard)' | '100% (Extra Sweet)';
  iceLevel?: 'None' | 'Light Ice' | 'Regular Ice' | 'Extra Ice';
  extras: string[]; // e.g., 'Extra Espresso Shot', 'Caramel Drizzle', 'Vanilla Bean Syrup', 'Cinnamon Dust'
  grindSize?: string;
  notes?: string;
}

export interface CartItem {
  cartItemId: string;
  item: CoffeeItem;
  options: CustomizationOptions;
  unitPrice: number;
  quantity: number;
}

export interface CoffeeBean {
  id: string;
  name: string;
  origin: string;
  altitude: string;
  process: string;
  roastLevel: 'Light Roast' | 'Medium-Light' | 'Medium' | 'Dark Roast';
  tastingNotes: string[];
  price: number;
  image: string;
  rating: number;
  bagSize: string;
  description: string;
}

export interface BrewStep {
  name: string;
  timeSec: number;
  waterAmountGrams: number;
  instruction: string;
}

export interface BrewGuide {
  id: string;
  name: string;
  ratio: string;
  ratioMultiplier: number; // e.g. 16 for 1:16
  grindSize: string;
  waterTemp: string;
  brewTime: string;
  idealDose: number; // in grams
  difficulty: 'Easy' | 'Moderate' | 'Artisan';
  description: string;
  icon: string;
  steps: BrewStep[];
}

export interface LocationInfo {
  id: string;
  name: string;
  address: string;
  city: string;
  hours: string;
  phone: string;
  status: 'Open Now' | 'Closes at 8:00 PM';
  features: string[];
}
