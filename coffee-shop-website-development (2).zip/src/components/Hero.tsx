import React from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { Sparkles, ArrowRight, Award, ShieldCheck, Coffee, Star } from 'lucide-react';

export const Hero: React.FC = () => {
  const { setIsQuizOpen, setIsReservationOpen } = useCoffee();

  const scrollToMenu = () => {
    const el = document.getElementById('menu');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="relative bg-[#140e0a] text-[#fbf7f2] overflow-hidden pt-8 pb-16 lg:py-24 border-b border-[#2c1c11]">
      {/* Background ambient radial gradients */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#c59b6d]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 left-10 w-96 h-96 bg-[#9d6b38]/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headline and Call to Actions */}
          <div className="lg:col-span-7 text-center lg:text-left space-y-6">
            
            {/* Top pill badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#25170f] border border-[#4a2e1d] shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#e76f51] animate-ping" />
              <span className="text-xs font-semibold tracking-wide text-[#f4a261] uppercase">
                Artisan Roastery & Micro-Lot Cafe
              </span>
              <span className="text-xs text-[#a88261]">• Est. 2018</span>
            </div>

            {/* Main Title */}
            <h1 className="font-serif-coffee text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-[#fbf7f2] leading-[1.12]">
              Where every single sip{' '}
              <span className="italic font-normal bg-gradient-to-r from-[#e9c46a] via-[#f4a261] to-[#e76f51] bg-clip-text text-transparent">
                awakens
              </span>{' '}
              your senses.
            </h1>

            {/* Subtext */}
            <p className="text-base sm:text-lg text-[#d8c3b0] max-w-2xl mx-auto lg:mx-0 leading-relaxed font-light">
              Ethically sourced direct from single-estate family farms in Ethiopia, Colombia, and Guatemala. 
              Small-batch roasted every 48 hours for vibrant floral highs and rich chocolate depths.
            </p>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={scrollToMenu}
                className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-gradient-to-r from-[#c59b6d] to-[#9d6b38] hover:from-[#d4a373] hover:to-[#b07d47] text-[#140e0a] font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xl shadow-[#9d6b38]/25 hover:scale-105 active:scale-95 transition-all"
              >
                <span>Explore Menu & Order</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsQuizOpen(true)}
                className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-[#241710] hover:bg-[#322016] text-[#e8dacb] border border-[#5a3621] font-semibold text-sm sm:text-base flex items-center justify-center gap-2 transition-all"
              >
                <Sparkles className="w-4 h-4 text-[#f4a261]" />
                <span>Find Your Perfect Roast</span>
              </button>

              <button
                onClick={() => setIsReservationOpen(true)}
                className="w-full sm:w-auto text-xs font-semibold text-[#c59b6d] hover:text-[#f4a261] underline underline-offset-4 py-2"
              >
                Book a Table / Tasting
              </button>
            </div>

            {/* Quick highlight points */}
            <div className="pt-6 border-t border-[#2d1b11] grid grid-cols-3 gap-4 text-center sm:text-left">
              <div>
                <div className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#e9c46a]">88+</div>
                <div className="text-xs text-[#a88261] font-medium mt-0.5">SCA Specialty Score</div>
              </div>
              <div>
                <div className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#e9c46a]">48h</div>
                <div className="text-xs text-[#a88261] font-medium mt-0.5">Peak Freshness Roast</div>
              </div>
              <div>
                <div className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#e9c46a]">100%</div>
                <div className="text-xs text-[#a88261] font-medium mt-0.5">Direct Farm Trade</div>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Outer decorative ring */}
              <div className="absolute -inset-3 rounded-3xl bg-gradient-to-tr from-[#9d6b38]/40 via-[#e76f51]/20 to-transparent blur-lg opacity-70" />

              {/* Main image container */}
              <div className="relative rounded-2xl overflow-hidden border-2 border-[#54331e] bg-[#22160f] shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/15801079/pexels-photo-15801079.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
                  alt="Barista creating intricate latte art at Terra and Roast"
                  className="w-full h-[400px] sm:h-[460px] object-cover hover:scale-105 transition-transform duration-700"
                />

                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#140e0a] via-transparent to-black/20" />

                {/* Floating pill: Signature latte */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#1e130c]/90 backdrop-blur-md p-4 rounded-xl border border-[#4f2f1a] flex items-center justify-between shadow-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#3f2414] flex items-center justify-center text-[#f4a261]">
                      <Coffee className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#fbf7f2]">Honey Lavender Latte</h4>
                      <p className="text-xs text-[#b89574]">Double shot • French lavender • Oat milk</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-[#f4a261]">$6.75</div>
                    <div className="flex items-center text-[10px] text-amber-400 gap-0.5">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>4.9 (340+)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating top badge */}
              <div className="absolute -top-4 -left-4 bg-[#2b170e] text-[#fbf7f2] border border-[#643a20] px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2.5 animate-bounce [animation-duration:4s]">
                <div className="p-1.5 rounded-lg bg-[#e76f51]/20 text-[#f4a261]">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold">2026 Golden Bean Winner</div>
                  <div className="text-[10px] text-[#b89574]">Best Specialty Micro-Lot</div>
                </div>
              </div>

              {/* Floating bottom right badge */}
              <div className="hidden sm:flex absolute -bottom-3 -right-3 bg-[#241710] text-[#fbf7f2] border border-[#522e1b] px-3.5 py-2 rounded-xl shadow-xl items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-medium text-[#d8c3b0]">Fair Farmer Premium Paid</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </header>
  );
};
