import React, { useState } from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { X, Calendar, Clock, Users, CheckCircle2, MapPin, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

export const TableReservationModal: React.FC = () => {
  const { isReservationOpen, setIsReservationOpen } = useCoffee();
  const [type, setType] = useState<'table' | 'workshop'>('table');
  const [location, setLocation] = useState('Flagship Roastery (Downtown)');
  const [partySize, setPartySize] = useState('2 Guests');
  const [date, setDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [time, setTime] = useState('10:30 AM');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [confirmedBookingId, setConfirmedBookingId] = useState<string | null>(null);

  if (!isReservationOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const bookingId = `TR-${Math.floor(100000 + Math.random() * 900000)}`;
    setConfirmedBookingId(bookingId);
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  };

  const handleClose = () => {
    setIsReservationOpen(false);
    setConfirmedBookingId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-[#faf6f0] text-[#2b1f17] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#dbc6b2] relative animate-scaleIn max-h-[92vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <button
          onClick={handleClose}
          aria-label="Close Reservation"
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#ebe0d4] text-[#4d3627] flex items-center justify-center hover:bg-[#decfc0] transition"
        >
          <X className="w-4 h-4" />
        </button>

        {confirmedBookingId ? (
          <div className="text-center space-y-5 py-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#8c7462]">
                Reservation Confirmed
              </span>
              <h3 className="font-serif-coffee text-2xl font-bold text-[#1f140e] mt-1">
                We're Saving Your Spot!
              </h3>
              <p className="text-xs text-[#6e5849] mt-1">
                A confirmation text & calendar invite have been sent to {email || 'your email'}.
              </p>
            </div>

            {/* Booking Details Card */}
            <div className="bg-white p-5 rounded-2xl border border-[#ebdacf] text-left text-xs space-y-2.5">
              <div className="flex justify-between border-b pb-2">
                <span className="text-[#8c7462]">Confirmation Code:</span>
                <span className="font-mono font-bold text-[#1e130c]">{confirmedBookingId}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-[#8c7462]">Experience:</span>
                <span className="font-bold text-[#1e130c]">{type === 'workshop' ? 'Cupping & Latte Art Masterclass' : 'Cozy Cafe Table'}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-[#8c7462]">Date & Time:</span>
                <span className="font-bold text-[#1e130c]">{date} at {time}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-[#8c7462]">Party Size:</span>
                <span className="font-bold text-[#1e130c]">{partySize}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8c7462]">Location:</span>
                <span className="font-bold text-[#1e130c]">{location}</span>
              </div>
            </div>

            <button
              onClick={handleClose}
              className="w-full py-3 rounded-xl bg-[#2b1b11] hover:bg-[#3d2417] text-[#fbf7f2] font-bold text-sm transition"
            >
              Done & Return to Cafe
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f4ebd9] text-[#8c582f] text-xs font-bold uppercase tracking-wider mb-2 border border-[#deb887]/50">
                <Calendar className="w-3.5 h-3.5 text-[#d48c46]" /> Hospitality & Tastings
              </div>
              <h3 className="font-serif-coffee text-2xl font-bold text-[#1f140e]">
                Reserve Your Experience
              </h3>
              <p className="text-xs text-[#735845] mt-1">
                Book a peaceful reading booth, a meeting table, or join our weekend coffee tasting session.
              </p>
            </div>

            {/* Type tabs */}
            <div className="grid grid-cols-2 gap-2 bg-[#ebdccf]/50 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setType('table')}
                className={`py-2 text-xs font-bold rounded-lg transition ${
                  type === 'table' ? 'bg-white text-[#2b1f17] shadow-sm' : 'text-[#735845]'
                }`}
              >
                Cafe Table Booking
              </button>
              <button
                type="button"
                onClick={() => setType('workshop')}
                className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1 ${
                  type === 'workshop' ? 'bg-[#2b1b11] text-[#fbf7f2] shadow-sm' : 'text-[#735845]'
                }`}
              >
                <Sparkles className="w-3 h-3 text-[#f4a261]" /> Cupping Class
              </button>
            </div>

            {/* Location selector */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1.5">
                Location
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9c8473]" />
                <select
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17] focus:ring-2 focus:ring-[#9d6b38]"
                >
                  <option>Flagship Roastery (Downtown Arts District)</option>
                  <option>The Greenhouse Espresso Bar (Uptown)</option>
                </select>
              </div>
            </div>

            {/* Party Size & Date / Time */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1.5">
                  Guests
                </label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9c8473]" />
                  <select
                    value={partySize}
                    onChange={e => setPartySize(e.target.value)}
                    className="w-full pl-9 pr-2 py-2.5 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
                  >
                    <option>1 Guest</option>
                    <option>2 Guests</option>
                    <option>3 Guests</option>
                    <option>4 Guests</option>
                    <option>5-8 Guests</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1.5">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  required
                  className="w-full px-3 py-2.5 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1.5">
                  Time Slot
                </label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9c8473]" />
                  <select
                    value={time}
                    onChange={e => setTime(e.target.value)}
                    className="w-full pl-9 pr-2 py-2.5 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
                  >
                    <option>8:00 AM</option>
                    <option>9:30 AM</option>
                    <option>10:30 AM</option>
                    <option>12:00 PM</option>
                    <option>1:30 PM</option>
                    <option>3:00 PM</option>
                    <option>4:30 PM</option>
                    <option>6:00 PM</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Contact Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1">
                  Your Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Jordan Hayes"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="jordan@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1">
                Phone Number (for SMS reminder)
              </label>
              <input
                type="tel"
                placeholder="(503) 555-0123"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1">
                Special Requests or Dietary Notes
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Bringing a friendly pup on patio, celebrating anniversary, etc."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#9d6b38] to-[#7d4e2d] hover:from-[#af773f] hover:to-[#8c5732] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg transition"
            >
              <Calendar className="w-4 h-4" />
              <span>Confirm Reservation (Instant Free Hold)</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
