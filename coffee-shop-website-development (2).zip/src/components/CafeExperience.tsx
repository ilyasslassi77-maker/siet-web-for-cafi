import React from 'react';
import { REVIEWS } from '../data/coffeeData';
import { useCoffee } from '../context/CoffeeContext';
import { Wifi, Music, Sun, Dog, Calendar, Star, Quote } from 'lucide-react';

export const CafeExperience: React.FC = () => {
  const { setIsReservationOpen } = useCoffee();

  const spaceHighlights = [
    {
      title: 'Dedicated Work Spaces',
      desc: 'Gigabit fiber Wi-Fi, ample power outlets at every booth, and ergonomic oak seating.',
      icon: Wifi
    },
    {
      title: 'Curated Vinyl Listening Bar',
      desc: 'Analog turntable spinning warm Japanese jazz, rare soul, and ambient lo-fi selections all day.',
      icon: Music
    },
    {
      title: 'Sunlit Solarium & Greenery',
      desc: 'Enclosed botanical greenhouse section bathed in soft natural morning sunlight.',
      icon: Sun
    },
    {
      title: 'Dog-Friendly Heated Patio',
      desc: 'Covered outdoor deck with radiant heaters, fresh water bowls, and complimentary puppuccinos.',
      icon: Dog
    }
  ];

  return (
    <section className="py-20 bg-[#faf5ef] text-[#2b1f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f1e4d6] text-[#8c582f] text-xs font-bold uppercase tracking-wider mb-3 border border-[#deb887]/50">
            A Third Place To Belong
          </div>
          <h2 className="font-serif-coffee text-3xl sm:text-4xl md:text-5xl font-bold text-[#1f140e] tracking-tight">
            More Than Just A Coffee Shop
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#6b584c] leading-relaxed">
            Designed as a sanctuary from the rush. Whether you're penning your next novel, meeting friends, 
            or savoring a quiet morning pour-over, you'll feel right at home.
          </p>
        </div>

        {/* Space Highlights Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {spaceHighlights.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white p-6 rounded-2xl border border-[#ebdacf] shadow-sm hover:shadow-md transition space-y-3"
              >
                <div className="w-12 h-12 rounded-xl bg-[#2b1b11] text-[#f4a261] flex items-center justify-center">
                  <Icon className="w-6 h-6" />
                </div>
                <h4 className="font-serif-coffee text-lg font-bold text-[#1e130c]">
                  {item.title}
                </h4>
                <p className="text-xs text-[#6e5849] leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Cafe Gallery Photo Collage */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-16">
          <div className="relative h-64 md:h-80 rounded-2xl overflow-hidden shadow-md">
            <img
              src="https://images.pexels.com/photos/33188113/pexels-photo-33188113.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt="Warm cafe interior with pastry counter"
              className="w-full h-full object-cover hover:scale-105 transition duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-5">
              <span className="text-white text-sm font-bold font-serif-coffee">Fresh Pastry Display & Brew Bar</span>
            </div>
          </div>

          <div className="relative h-64 md:h-80 rounded-2xl overflow-hidden shadow-md">
            <img
              src="https://images.pexels.com/photos/14630368/pexels-photo-14630368.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt="Artisan latte and toast on cafe table"
              className="w-full h-full object-cover hover:scale-105 transition duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-5">
              <span className="text-white text-sm font-bold font-serif-coffee">Sunlit Breakfast Table</span>
            </div>
          </div>

          <div className="relative h-64 md:h-80 rounded-2xl overflow-hidden shadow-md">
            <img
              src="https://images.pexels.com/photos/30855411/pexels-photo-30855411.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt="Cozy window counter seating"
              className="w-full h-full object-cover hover:scale-105 transition duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-5">
              <span className="text-white text-sm font-bold font-serif-coffee">Historic Brick Window Seats</span>
            </div>
          </div>
        </div>

        {/* Customer Reviews Section */}
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-[#ebdacf] shadow-sm">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 pb-6 border-b border-[#f0e4d7]">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#9d6b38]">
                Community Love & Stories
              </span>
              <h3 className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#1f140e] mt-1">
                Cherished By Specialty Coffee Devotees
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-400" />
                ))}
              </div>
              <span className="text-sm font-bold text-[#1e130c]">4.9 / 5.0 (1,240+ Reviews)</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS.map(rev => (
              <div key={rev.id} className="space-y-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 text-amber-400 mb-2">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>

                  <p className="text-xs sm:text-sm text-[#5a4637] leading-relaxed italic relative">
                    <Quote className="w-5 h-5 text-[#debfa6] inline-block -mt-2 mr-1" />
                    "{rev.comment}"
                  </p>
                </div>

                <div className="pt-3 border-t border-[#f2e7dc] flex items-center gap-3">
                  <img
                    src={rev.avatar}
                    alt={rev.author}
                    className="w-10 h-10 rounded-full object-cover border border-[#9d6b38]"
                  />
                  <div>
                    <h5 className="text-xs font-bold text-[#1e130c]">{rev.author}</h5>
                    <span className="text-[10px] text-[#8c7462] block">{rev.role}</span>
                    <span className="text-[10px] text-[#9d6b38] font-medium">Favorite: {rev.drink}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Reserve table prompt */}
          <div className="mt-10 pt-8 border-t border-[#f0e4d7] flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs sm:text-sm text-[#735e50] text-center sm:text-left">
              Want to reserve a table for your team or join our Saturday cupping workshop?
            </span>
            <button
              onClick={() => setIsReservationOpen(true)}
              className="px-6 py-2.5 rounded-full bg-[#2b1b11] hover:bg-[#3d2417] text-[#fbf7f2] font-semibold text-xs flex items-center gap-2 transition"
            >
              <Calendar className="w-3.5 h-3.5 text-[#f4a261]" />
              <span>Reserve a Table Online</span>
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
