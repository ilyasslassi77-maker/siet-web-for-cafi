import React, { useState, useEffect } from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { CheckCircle2, Clock, MapPin, Coffee, Flame, Sparkles, X, ChevronRight } from 'lucide-react';

export const OrderSuccessModal: React.FC = () => {
  const { activeOrder, setActiveOrder } = useCoffee();
  const [currentStep, setCurrentStep] = useState(1);

  useEffect(() => {
    if (!activeOrder) return;
    
    // Simulate barista preparation progress
    const timer1 = setTimeout(() => setCurrentStep(2), 3500);
    const timer2 = setTimeout(() => setCurrentStep(3), 8500);
    const timer3 = setTimeout(() => setCurrentStep(4), 14000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [activeOrder]);

  if (!activeOrder) return null;

  const steps = [
    { num: 1, title: 'Order Received', desc: 'Sent to barista espresso bar', icon: Sparkles },
    { num: 2, title: 'Dialing & Grinding', desc: 'Precision burr grinding beans', icon: Flame },
    { num: 3, title: 'Brewing & Steaming', desc: 'Pulling 9-bar shot & microfoam art', icon: Coffee },
    { num: 4, title: 'Ready for Pickup', desc: 'Waiting at the bar with your name', icon: CheckCircle2 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div 
        className="bg-[#faf6f0] text-[#2b1f17] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#dbc6b2] relative animate-scaleIn max-h-[92vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <button
          onClick={() => setActiveOrder(null)}
          aria-label="Close Order Modal"
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#ebe0d4] text-[#4d3627] flex items-center justify-center hover:bg-[#decfc0] transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Status */}
        <div className="text-center space-y-2 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-[#2b1b11] text-[#f4a261] mx-auto flex items-center justify-center shadow-lg">
            <Coffee className="w-8 h-8" />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider text-[#8c7462]">
            Order #{activeOrder.orderId}
          </span>
          <h3 className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#1f140e]">
            Your Coffee Is Being Crafted
          </h3>
          <p className="text-xs text-[#735845]">
            Estimated ready in <strong>{activeOrder.pickupTime}</strong>
          </p>
        </div>

        {/* Live Step Tracker */}
        <div className="bg-white p-5 rounded-2xl border border-[#ebdacf] mb-6 space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#8c7462] flex items-center justify-between">
            <span>Live Barista Progress</span>
            <span className="text-[#9d6b38] font-bold">Step {currentStep} of 4</span>
          </h4>

          <div className="space-y-3">
            {steps.map(s => {
              const Icon = s.icon;
              const isPast = s.num < currentStep;
              const isCurrent = s.num === currentStep;

              return (
                <div
                  key={s.num}
                  className={`flex items-center gap-3 p-2.5 rounded-xl transition ${
                    isCurrent
                      ? 'bg-[#f7efe6] border border-[#d8c2ad]'
                      : isPast
                      ? 'text-[#7e6858]'
                      : 'opacity-40 text-[#a89587]'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                    isCurrent
                      ? 'bg-[#9d6b38] text-white animate-pulse'
                      : isPast
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#ede0d2] text-[#8c7462]'
                  }`}>
                    {isPast ? <CheckCircle2 className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-[#1e130c] flex items-center gap-1.5">
                      <span>{s.title}</span>
                      {isCurrent && (
                        <span className="inline-block w-2 h-2 rounded-full bg-[#f4a261] animate-ping" />
                      )}
                    </div>
                    <div className="text-[11px] text-[#786151] truncate">{s.desc}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Order Details Accordion */}
        <div className="bg-white p-5 rounded-2xl border border-[#ebdacf] mb-6 space-y-3 text-xs">
          <div className="flex items-center justify-between font-bold text-[#1e130c] border-b pb-2">
            <span>Items Ordered ({activeOrder.items.length})</span>
            <span>Total: ${activeOrder.total.toFixed(2)}</span>
          </div>

          <div className="space-y-2 max-h-36 overflow-y-auto">
            {activeOrder.items.map((ci: any) => (
              <div key={ci.cartItemId} className="flex justify-between items-center text-[11px]">
                <div className="truncate mr-2">
                  <span className="font-bold">{ci.quantity}x</span> {ci.item.name}
                  <span className="text-[#8c7462] block text-[10px]">
                    {ci.options.grindSize || `${ci.options.size} • ${ci.options.milk}`}
                  </span>
                </div>
                <span className="font-semibold text-[#1e130c]">
                  ${(ci.unitPrice * ci.quantity).toFixed(2)}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t text-[11px] text-[#735845] flex items-center gap-2">
            {activeOrder.fulfillmentType === 'pickup' ? (
              <>
                <MapPin className="w-4 h-4 text-[#9d6b38] shrink-0" />
                <span>Pickup Counter: <strong>428 Timber & Stone Way, Portland OR</strong></span>
              </>
            ) : (
              <>
                <Clock className="w-4 h-4 text-[#9d6b38] shrink-0" />
                <span>Delivering to: <strong>{activeOrder.address}</strong></span>
              </>
            )}
          </div>
        </div>

        {/* Dismiss button */}
        <button
          onClick={() => setActiveOrder(null)}
          className="w-full py-3.5 rounded-xl bg-[#2b1b11] hover:bg-[#3d2417] text-[#fbf7f2] font-bold text-sm transition flex items-center justify-center gap-2"
        >
          <span>Done • Return to Roastery Site</span>
          <ChevronRight className="w-4 h-4" />
        </button>

      </div>
    </div>
  );
};
