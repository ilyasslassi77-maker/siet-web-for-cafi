import React, { useState, useEffect } from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { 
  Coffee, 
  ShoppingBag, 
  Sparkles, 
  Calendar, 
  Menu as MenuIcon, 
  X, 
  Clock, 
  MapPin, 
  Flame,
  Search
} from 'lucide-react';

interface NavbarProps {
  onSearchClick: () => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onSearchClick }) => {
  const { cartCount, cartSubtotal, setIsCartOpen, setIsQuizOpen, setIsReservationOpen } = useCoffee();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Announcement top bar */}
      <div className="bg-[#1c130c] text-[#d4a373] text-xs py-2 px-4 border-b border-[#3d2719] relative z-50">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1 text-center sm:text-left">
          <div className="flex items-center justify-center gap-2 font-medium">
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] bg-[#3a2012] text-[#f4a261] font-semibold border border-[#522e1b]">
              <Flame className="w-3 h-3 mr-1 text-[#e76f51]" /> FRESH ROAST
            </span>
            <span>Ethiopia Yirgacheffe G1 & Colombia Pink Bourbon just roasted today!</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-[#b89574]">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#2a9d8f]" />
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse inline-block mr-1"></span>
              Open Now • 7:00 AM – 8:00 PM
            </span>
            <span className="hidden md:flex items-center gap-1">
              <MapPin className="w-3 h-3" /> Portland Arts District
            </span>
          </div>
        </div>
      </div>

      {/* Main sticky navigation */}
      <nav
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#18110b]/95 backdrop-blur-md shadow-xl py-3 border-b border-[#382315]'
            : 'bg-[#18110b] py-4 border-b border-[#2a1a0f]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-3 group text-left"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#c59b6d] to-[#7d4e2d] flex items-center justify-center text-[#18110b] shadow-md group-hover:scale-105 transition-transform duration-200">
                <Coffee className="w-6 h-6 stroke-[2.2]" />
              </div>
              <div>
                <span className="font-serif-coffee text-xl sm:text-2xl font-bold tracking-tight text-[#fbf7f2] flex items-center gap-1">
                  TERRA <span className="text-[#c59b6d] font-normal italic">&</span> ROAST
                </span>
                <span className="block text-[10px] tracking-widest uppercase text-[#a88261] font-semibold -mt-0.5">
                  Artisan Coffee Roasters
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <div className="hidden lg:flex items-center space-x-1 xl:space-x-2 text-sm font-medium text-[#e8dacb]">
              <button
                onClick={() => scrollToSection('menu')}
                className="px-3 py-2 rounded-lg hover:text-[#f4a261] hover:bg-[#281c13] transition-colors"
              >
                Cafe Menu
              </button>
              <button
                onClick={() => scrollToSection('beans')}
                className="px-3 py-2 rounded-lg hover:text-[#f4a261] hover:bg-[#281c13] transition-colors"
              >
                Whole Beans & Bags
              </button>
              <button
                onClick={() => scrollToSection('brewing')}
                className="px-3 py-2 rounded-lg hover:text-[#f4a261] hover:bg-[#281c13] transition-colors"
              >
                Brew Calculator
              </button>
              <button
                onClick={() => setIsQuizOpen(true)}
                className="px-3 py-2 rounded-lg text-[#f4a261] bg-[#361e12]/60 hover:bg-[#361e12] border border-[#693d25] flex items-center gap-1.5 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#e76f51]" />
                Flavor Quiz
              </button>
              <button
                onClick={() => scrollToSection('story')}
                className="px-3 py-2 rounded-lg hover:text-[#f4a261] hover:bg-[#281c13] transition-colors"
              >
                Our Roastery
              </button>
              <button
                onClick={() => scrollToSection('locations')}
                className="px-3 py-2 rounded-lg hover:text-[#f4a261] hover:bg-[#281c13] transition-colors"
              >
                Locations
              </button>
            </div>

            {/* Right Action Buttons */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Search shortcut button */}
              <button
                onClick={onSearchClick}
                aria-label="Search coffee menu"
                className="p-2.5 rounded-full text-[#c59b6d] hover:bg-[#2a1b12] hover:text-[#fbf7f2] transition-colors"
              >
                <Search className="w-4 h-4" />
              </button>

              {/* Table reservation button */}
              <button
                onClick={() => setIsReservationOpen(true)}
                className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold px-3.5 py-2 rounded-full border border-[#7d4e2d] text-[#e8dacb] hover:bg-[#2d1b11] transition-colors"
              >
                <Calendar className="w-3.5 h-3.5 text-[#c59b6d]" />
                Reserve Table
              </button>

              {/* Cart Drawer Trigger */}
              <button
                onClick={() => setIsCartOpen(true)}
                aria-label="Open Cart"
                className="relative flex items-center gap-2 bg-gradient-to-r from-[#c59b6d] to-[#9d6b38] hover:from-[#d4a373] hover:to-[#b07d47] text-[#18110b] font-semibold text-xs sm:text-sm px-3.5 sm:px-4 py-2 sm:py-2.2 rounded-full shadow-lg shadow-[#7d4e2d]/30 hover:scale-105 active:scale-95 transition-all duration-200"
              >
                <ShoppingBag className="w-4 h-4 text-[#18110b]" />
                <span className="hidden xs:inline">Order</span>
                {cartCount > 0 && (
                  <span className="bg-[#18110b] text-[#f4a261] text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center -ml-0.5 shadow">
                    {cartCount}
                  </span>
                )}
                {cartSubtotal > 0 && (
                  <span className="hidden md:inline font-bold border-l border-[#704222] pl-2 text-xs">
                    ${cartSubtotal.toFixed(2)}
                  </span>
                )}
              </button>

              {/* Mobile Hamburger Toggle */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-[#d4a373] hover:bg-[#2a1c13] transition-colors"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile dropdown menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#1c130c] border-b border-[#382315] px-4 pt-3 pb-6 space-y-2 animate-fadeIn">
            <button
              onClick={() => scrollToSection('menu')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-[#fbf7f2] hover:bg-[#2c1b11] flex items-center justify-between"
            >
              <span>Cafe Drinks & Bakery</span>
              <Coffee className="w-4 h-4 text-[#c59b6d]" />
            </button>
            <button
              onClick={() => scrollToSection('beans')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-[#fbf7f2] hover:bg-[#2c1b11] flex items-center justify-between"
            >
              <span>Fresh Whole Beans</span>
              <Flame className="w-4 h-4 text-[#e76f51]" />
            </button>
            <button
              onClick={() => scrollToSection('brewing')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-[#fbf7f2] hover:bg-[#2c1b11] flex items-center justify-between"
            >
              <span>Interactive Brew Calculator</span>
              <Clock className="w-4 h-4 text-[#c59b6d]" />
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsQuizOpen(true);
              }}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-[#f4a261] bg-[#361e12] border border-[#693d25] flex items-center justify-between"
            >
              <span>Take Coffee Flavor Quiz</span>
              <Sparkles className="w-4 h-4 text-[#e76f51]" />
            </button>
            <button
              onClick={() => scrollToSection('story')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-[#fbf7f2] hover:bg-[#2c1b11]"
            >
              Our Story & Ethical Sourcing
            </button>
            <button
              onClick={() => scrollToSection('locations')}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium text-[#fbf7f2] hover:bg-[#2c1b11]"
            >
              Hours & Locations
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsReservationOpen(true);
              }}
              className="w-full mt-2 py-2.5 text-center rounded-lg text-sm font-semibold border border-[#7d4e2d] text-[#e8dacb] hover:bg-[#2d1b11] flex items-center justify-center gap-2"
            >
              <Calendar className="w-4 h-4 text-[#c59b6d]" />
              Reserve a Table or Cupping Workshop
            </button>
          </div>
        )}
      </nav>
    </>
  );
};
