import React, { useState, useEffect, useRef } from 'react';
import { BREW_GUIDES } from '../data/coffeeData';
import { BrewGuide } from '../types';
import { playChime } from '../utils/audio';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Flame, 
  Sliders, 
  CheckCircle2, 
  Sparkles,
  Award
} from 'lucide-react';

export const BrewCalculatorTimer: React.FC = () => {
  const [selectedGuide, setSelectedGuide] = useState<BrewGuide>(BREW_GUIDES[0]);
  const [doseGrams, setDoseGrams] = useState<number>(selectedGuide.idealDose);
  
  // Timer state
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);
  const timerRef = useRef<number | null>(null);

  // Update dose when changing method
  const handleSelectGuide = (guide: BrewGuide) => {
    setSelectedGuide(guide);
    setDoseGrams(guide.idealDose);
    resetTimer();
  };

  // Water calculation
  const totalWaterGrams = Math.round(doseGrams * selectedGuide.ratioMultiplier);

  // Total brew duration in seconds based on steps
  const totalTargetSeconds = selectedGuide.steps.reduce((acc, step) => acc + step.timeSec, 0);

  // Determine current active step
  let accumulatedSeconds = 0;
  let currentStepIndex = 0;
  for (let i = 0; i < selectedGuide.steps.length; i++) {
    accumulatedSeconds += selectedGuide.steps[i].timeSec;
    if (secondsElapsed < accumulatedSeconds) {
      currentStepIndex = i;
      break;
    }
    if (i === selectedGuide.steps.length - 1) {
      currentStepIndex = selectedGuide.steps.length - 1;
    }
  }

  const currentStep = selectedGuide.steps[currentStepIndex];
  const isFinished = secondsElapsed >= totalTargetSeconds;

  useEffect(() => {
    if (timerRunning) {
      timerRef.current = window.setInterval(() => {
        setSecondsElapsed(prev => {
          const next = prev + 1;
          // Check if entering a new step
          let stepSum = 0;
          for (let step of selectedGuide.steps) {
            stepSum += step.timeSec;
            if (next === stepSum) {
              playChime(659.25, 0.5);
              break;
            }
          }
          if (next >= totalTargetSeconds) {
            playChime(880, 0.7);
            setTimerRunning(false);
          }
          return next;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerRunning, selectedGuide, totalTargetSeconds]);

  const toggleTimer = () => {
    if (isFinished) {
      setSecondsElapsed(0);
      setTimerRunning(true);
    } else {
      setTimerRunning(prev => !prev);
    }
  };

  const resetTimer = () => {
    setTimerRunning(false);
    setSecondsElapsed(0);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = Math.min(100, Math.round((secondsElapsed / totalTargetSeconds) * 100));

  return (
    <section id="brewing" className="py-20 bg-[#fbf7f2] text-[#2b1f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f4ebd9] text-[#8c582f] text-xs font-bold uppercase tracking-wider mb-3 border border-[#deb887]/50">
            <Sliders className="w-3.5 h-3.5 text-[#d48c46]" /> Barista Science & Ratios
          </div>
          <h2 className="font-serif-coffee text-3xl sm:text-4xl md:text-5xl font-bold text-[#1f140e] tracking-tight">
            Interactive Brew Ratio & Timer Lab
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#6b584c] leading-relaxed">
            The difference between good coffee and sublime coffee is water weight, temperature, and extraction time. 
            Adjust your dose below and brew with our live step stopwatch.
          </p>
        </div>

        {/* Method Selector Tabs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-4xl mx-auto mb-10">
          {BREW_GUIDES.map(guide => {
            const isSelected = selectedGuide.id === guide.id;
            return (
              <button
                key={guide.id}
                onClick={() => handleSelectGuide(guide)}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  isSelected
                    ? 'bg-[#1e130c] text-[#fbf7f2] border-[#1e130c] shadow-lg scale-102'
                    : 'bg-white text-[#5c4637] border-[#e8dacf] hover:bg-[#f6eee4]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-xs font-bold uppercase tracking-wider ${isSelected ? 'text-[#f4a261]' : 'text-[#9c8473]'}`}>
                    {guide.difficulty}
                  </span>
                  <span className="text-xs font-bold">{guide.ratio.split(' ')[0]}</span>
                </div>
                <div className="font-serif-coffee text-base sm:text-lg font-bold leading-tight">
                  {guide.name}
                </div>
              </button>
            );
          })}
        </div>

        {/* Calculator & Live Timer Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto">
          
          {/* Left Column: Ratio & Dose Slider */}
          <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-3xl border border-[#ebdacf] shadow-sm space-y-6">
            <div>
              <h3 className="font-serif-coffee text-2xl font-bold text-[#1e130c]">
                Dial-In Specifications
              </h3>
              <p className="text-xs text-[#735e50] mt-1">
                {selectedGuide.description}
              </p>
            </div>

            {/* Dose Slider */}
            <div className="bg-[#faf6f0] p-5 rounded-2xl border border-[#ede1d5]">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-[#735845]">
                  Coffee Grounds Dose
                </label>
                <span className="text-lg font-bold text-[#1e130c] font-serif-coffee bg-white px-3 py-1 rounded-lg border border-[#e2d5c7]">
                  {doseGrams}g
                </span>
              </div>
              <input
                type="range"
                min="12"
                max="60"
                step="1"
                value={doseGrams}
                onChange={e => {
                  setDoseGrams(Number(e.target.value));
                  resetTimer();
                }}
                className="w-full accent-[#9d6b38] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-[#9c8473] mt-1">
                <span>12g (Single Cup)</span>
                <span>30g (Carafe)</span>
                <span>60g (Batch)</span>
              </div>
            </div>

            {/* Calculated Values Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#ede1d5]">
                <div className="text-[11px] font-semibold text-[#8c7462] uppercase">Water Needed</div>
                <div className="text-2xl font-bold text-[#1e130c] font-serif-coffee mt-0.5">
                  {totalWaterGrams}g
                </div>
                <div className="text-[10px] text-[#8c7462]">({(totalWaterGrams / 29.57).toFixed(1)} fl oz)</div>
              </div>

              <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#ede1d5]">
                <div className="text-[11px] font-semibold text-[#8c7462] uppercase">Water Temp</div>
                <div className="text-2xl font-bold text-[#1e130c] font-serif-coffee mt-0.5">
                  {selectedGuide.waterTemp.split('/')[0]}
                </div>
                <div className="text-[10px] text-[#8c7462]">{selectedGuide.waterTemp.split('/')[1] || 'Just off boil'}</div>
              </div>

              <div className="p-4 rounded-xl bg-[#faf6f0] border border-[#ede1d5] col-span-2">
                <div className="text-[11px] font-semibold text-[#8c7462] uppercase">Recommended Grind Size</div>
                <div className="text-sm font-bold text-[#1e130c] mt-0.5">
                  {selectedGuide.grindSize}
                </div>
                <div className="text-[10px] text-[#8c7462]">Target total time: ~{selectedGuide.brewTime}</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#fff7eb] border border-[#f3dfc0] flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-[#d48c46] shrink-0" />
              <p className="text-xs text-[#7d5626]">
                <strong>Barista Tip:</strong> Use mineral-rich filtered water (120-150 ppm) to enhance floral and fruit esters.
              </p>
            </div>
          </div>

          {/* Right Column: Live Brew Assistant Timer */}
          <div className="lg:col-span-7 bg-[#1c130c] text-[#fbf7f2] p-6 sm:p-8 rounded-3xl border border-[#3b2416] shadow-xl flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#3b2416]">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-[#f4a261]" />
                  <span className="font-bold text-sm tracking-wide">Live Brew Assistant</span>
                </div>
                <div className="text-xs text-[#d8c3b0] bg-[#2d1b11] px-3 py-1 rounded-full border border-[#482b1b]">
                  {selectedGuide.name}
                </div>
              </div>

              {/* Big Stopwatch Display */}
              <div className="py-8 text-center">
                <div className="font-mono-coffee text-6xl sm:text-7xl font-bold text-[#fbf7f2] tracking-wider">
                  {formatTime(secondsElapsed)}
                </div>
                <div className="text-xs text-[#a88261] mt-1 uppercase tracking-widest font-semibold">
                  Target: {formatTime(totalTargetSeconds)}
                </div>

                {/* Progress bar */}
                <div className="w-full bg-[#2d1b11] h-3 rounded-full mt-5 overflow-hidden p-0.5 border border-[#482c1b]">
                  <div
                    className="bg-gradient-to-r from-[#9d6b38] via-[#e76f51] to-[#e9c46a] h-full rounded-full transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Current Active Step Box */}
              <div className="bg-[#241710] p-5 rounded-2xl border border-[#482c1b] mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#f4a261] uppercase tracking-wider">
                    Step {currentStepIndex + 1} of {selectedGuide.steps.length}: {currentStep.name}
                  </span>
                  {currentStep.waterAmountGrams > 0 && (
                    <span className="text-xs font-bold text-[#e9c46a] bg-[#3b2315] px-2.5 py-0.5 rounded-full border border-[#5d341f]">
                      Pour to {currentStep.waterAmountGrams}g
                    </span>
                  )}
                </div>
                <p className="text-sm text-[#e8dacb] leading-relaxed">
                  {isFinished ? '🎉 Brew Complete! Swirl carafe and enjoy the aromatic complexity.' : currentStep.instruction}
                </p>
              </div>

              {/* Step Checklist preview */}
              <div className="space-y-2 mb-6">
                {selectedGuide.steps.map((st, idx) => {
                  const isDone = idx < currentStepIndex;
                  const isCurrent = idx === currentStepIndex;
                  return (
                    <div
                      key={idx}
                      className={`text-xs p-2.5 rounded-xl flex items-center justify-between transition ${
                        isCurrent
                          ? 'bg-[#3b2416] text-[#fbf7f2] font-semibold border border-[#643a21]'
                          : isDone
                          ? 'text-[#a88a75] line-through'
                          : 'text-[#6e5645]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {isDone ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] ${isCurrent ? 'border-[#f4a261] text-[#f4a261]' : 'border-[#553b2a]'}`}>
                            {idx + 1}
                          </span>
                        )}
                        <span>{st.name} ({st.timeSec}s)</span>
                      </div>
                      {st.waterAmountGrams > 0 && (
                        <span>+{st.waterAmountGrams}g</span>
                      )}
                    </div>
                  );
                })}
              </div>

            </div>

            {/* Timer Controls */}
            <div className="flex items-center gap-3 pt-4 border-t border-[#3b2416]">
              <button
                onClick={toggleTimer}
                className={`flex-1 py-3.5 px-6 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition shadow-lg ${
                  timerRunning
                    ? 'bg-[#d94848] text-white hover:bg-[#bf3939]'
                    : isFinished
                    ? 'bg-[#2a9d8f] text-white hover:bg-[#238276]'
                    : 'bg-[#c59b6d] hover:bg-[#d4a373] text-[#18110b]'
                }`}
              >
                {timerRunning ? (
                  <>
                    <Pause className="w-5 h-5 fill-current" />
                    <span>Pause Brew</span>
                  </>
                ) : isFinished ? (
                  <>
                    <Award className="w-5 h-5" />
                    <span>Brew Again</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    <span>{secondsElapsed > 0 ? 'Resume Brew' : 'Start Brew Stopwatch'}</span>
                  </>
                )}
              </button>

              <button
                onClick={resetTimer}
                aria-label="Reset Timer"
                className="p-3.5 rounded-xl bg-[#2b1b11] hover:bg-[#3d2417] text-[#d8c3b0] transition border border-[#482c1b]"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
