import React, { useState, useMemo } from 'react';
import { MENU_ITEMS } from '../data/coffeeData';
import { ProductCategory, CoffeeItem } from '../types';
import { useCoffee } from '../context/CoffeeContext';
import { 
  Coffee, 
  Sparkles, 
  SlidersHorizontal, 
  Plus, 
  Star, 
  Search, 
  Flame, 
  Check, 
  Info,
  Droplet
} from 'lucide-react';

interface MenuSectionProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({ searchQuery, setSearchQuery }) => {
  const { addToCart, openCustomizer } = useCoffee();
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('all');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [addedItemAnimId, setAddedItemAnimId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Offerings', icon: Coffee },
    { id: 'signature', label: 'Signature Creations', icon: Sparkles },
    { id: 'espresso', label: 'Espresso Classics', icon: Droplet },
    { id: 'cold-brew', label: 'Cold Brew & Drafts', icon: Flame },
    { id: 'pour-over', label: 'Hand Pour Over', icon: SlidersHorizontal },
    { id: 'bakery', label: 'Artisan Bakery', icon: Coffee },
  ];

  // Extract all unique tags
  const allTags = useMemo(() => {
    const set = new Set<string>();
    MENU_ITEMS.forEach(item => item.tags.forEach(t => set.add(t)));
    return ['all', ...Array.from(set).slice(0, 7)];
  }, []);

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter(item => {
      const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
      const matchesSearch = searchQuery.trim() === '' || 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.flavorNotes.some(note => note.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesTag = selectedTag === 'all' || item.tags.includes(selectedTag);
      return matchesCategory && matchesSearch && matchesTag;
    });
  }, [activeCategory, searchQuery, selectedTag]);

  const handleQuickAdd = (item: CoffeeItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (item.customizable) {
      // If customizable, opening customizer is usually ideal, or quick add default
      addToCart(item);
    } else {
      addToCart(item);
    }
    setAddedItemAnimId(item.id);
    setTimeout(() => setAddedItemAnimId(null), 1200);
  };

  return (
    <section id="menu" className="py-20 bg-[#fbf7f2] text-[#2b1f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#f4ebd9] text-[#8c582f] text-xs font-bold uppercase tracking-wider mb-3 border border-[#deb887]/50">
            <Sparkles className="w-3.5 h-3.5 text-[#d48c46]" /> Handcrafted In Small Batches
          </div>
          <h2 className="font-serif-coffee text-3xl sm:text-4xl md:text-5xl font-bold text-[#1f140e] tracking-tight">
            The Roastery Cafe Menu
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#6b584c] leading-relaxed">
            Every beverage is pulled on our custom Synesso espresso machine with dialed-in grind sizes, 
            organic milks, and in-house made reductions.
          </p>
        </div>

        {/* Search bar & Quick Tag filter */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-[#e8dacf] mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search input */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9c8473]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search vanilla latte, cold brew, almond croissant..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#faf6f0] border border-[#e2d5c7] text-sm text-[#2b1f17] placeholder-[#a69282] focus:outline-none focus:ring-2 focus:ring-[#9d6b38]/40 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#8b7566] hover:text-[#2b1f17]"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Quick tag chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 scrollbar-none text-xs">
              <span className="text-[#8c7462] font-semibold whitespace-nowrap mr-1">Filter:</span>
              {allTags.map(tag => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag)}
                  className={`px-3 py-1.5 rounded-full transition whitespace-nowrap capitalize font-medium ${
                    selectedTag === tag
                      ? 'bg-[#2b1b11] text-[#fbf7f2]'
                      : 'bg-[#f4ebe1] text-[#6d5543] hover:bg-[#ebdccf]'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Category Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as ProductCategory)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl font-medium text-sm transition-all whitespace-nowrap shrink-0 shadow-sm ${
                  isActive
                    ? 'bg-[#1e130c] text-[#fbf7f2] shadow-md scale-[1.02]'
                    : 'bg-white text-[#5c4737] hover:bg-[#f6eee4] border border-[#e8ded4]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#e9c46a]' : 'text-[#a6866b]'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-[#d8c7b8]">
            <Coffee className="w-12 h-12 text-[#bfa48d] mx-auto mb-3" />
            <h3 className="text-lg font-bold text-[#2b1f17]">No coffee matching your search</h3>
            <p className="text-sm text-[#735e50] mt-1">Try searching for "latte", "nitro", or choose another category.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('all');
                setSelectedTag('all');
              }}
              className="mt-4 px-4 py-2 bg-[#2b1b11] text-[#fbf7f2] rounded-lg text-xs font-semibold"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredItems.map((item) => {
              const isAdded = addedItemAnimId === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => openCustomizer(item)}
                  className="group bg-white rounded-2xl overflow-hidden border border-[#ebdacf] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer hover:-translate-y-1"
                >
                  {/* Image container */}
                  <div className="relative h-56 sm:h-60 overflow-hidden bg-[#eee4d9]">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />

                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                    {/* Badge top-left */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                      {item.isPopular && (
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#e76f51] text-white shadow">
                          Popular Pick
                        </span>
                      )}
                      {item.isNew && (
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#2a9d8f] text-white shadow">
                          New Release
                        </span>
                      )}
                      {item.origin && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-[#1e130c]/80 text-[#e9c46a] backdrop-blur-sm">
                          Single Origin
                        </span>
                      )}
                    </div>

                    {/* Star Rating pill bottom-left */}
                    <div className="absolute bottom-3 left-3 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full text-white text-xs">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span className="font-bold">{item.rating}</span>
                      <span className="text-white/70 text-[10px]">({item.reviewsCount})</span>
                    </div>

                    {/* Price tag bottom-right */}
                    <div className="absolute bottom-3 right-3 bg-[#1e130c]/90 text-[#fbf7f2] font-bold px-3 py-1 rounded-lg text-sm shadow">
                      ${item.price.toFixed(2)}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-serif-coffee text-lg sm:text-xl font-bold text-[#1e130c] group-hover:text-[#9d6b38] transition-colors leading-snug">
                          {item.name}
                        </h3>
                      </div>

                      <p className="mt-2 text-xs sm:text-sm text-[#665243] line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Flavor notes tags */}
                      <div className="mt-3.5 pt-3 border-t border-[#f2e7dc]">
                        <span className="text-[11px] font-semibold text-[#8c7360] uppercase tracking-wider block mb-1.5">
                          Tasting Notes:
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {item.flavorNotes.map((note, i) => (
                            <span
                              key={i}
                              className="text-[11px] px-2 py-0.5 rounded-md bg-[#f7efe6] text-[#71553f] border border-[#ebdacf] font-medium"
                            >
                              {note}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Bottom action bar */}
                    <div className="mt-5 pt-3 border-t border-[#f2e7dc] flex items-center justify-between text-xs text-[#8c7462]">
                      <div className="flex items-center gap-3">
                        {item.calories && (
                          <span>{item.calories} cal</span>
                        )}
                        {item.caffeineMg && (
                          <span className="hidden sm:inline">• {item.caffeineMg}mg caffeine</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {item.customizable && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              openCustomizer(item);
                            }}
                            className="px-2.5 py-1.5 text-xs font-semibold text-[#8c582f] bg-[#fbf5ee] hover:bg-[#f1e4d3] rounded-lg border border-[#e2d0bf] transition"
                          >
                            Customize
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={(e) => handleQuickAdd(item, e)}
                          aria-label={`Add ${item.name} to order`}
                          className={`p-2 rounded-xl font-bold flex items-center justify-center transition-all ${
                            isAdded
                              ? 'bg-emerald-600 text-white scale-110'
                              : 'bg-[#1e130c] hover:bg-[#382315] text-[#fbf7f2] hover:scale-105 active:scale-95'
                          }`}
                        >
                          {isAdded ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <Plus className="w-4 h-4 stroke-[2.5]" />
                          )}
                        </button>
                      </div>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Barista tip banner */}
        <div className="mt-14 bg-gradient-to-r from-[#29180e] to-[#1c110a] rounded-2xl p-6 sm:p-8 text-[#fbf7f2] flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl border border-[#482c1b]">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-12 h-12 rounded-2xl bg-[#482917] flex items-center justify-center text-[#e9c46a] shrink-0">
              <Info className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base sm:text-lg font-bold">Have dietary preferences or bring your own cup?</h4>
              <p className="text-xs sm:text-sm text-[#d4b9a1] mt-0.5">
                We pour organic Oatly Barista, Califia Almond, and Decaf Swiss-Water espresso with zero upcharge on Wednesdays. 
                Bring your own mug for $0.50 off anytime.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              const el = document.getElementById('beans');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="whitespace-nowrap px-5 py-2.5 rounded-xl bg-[#c59b6d] hover:bg-[#d4a373] text-[#1a110a] font-bold text-xs sm:text-sm transition"
          >
            Explore Bean Roastery →
          </button>
        </div>

      </div>
    </section>
  );
};
