import React from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { CheckCircle2, Coffee } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toastMessage } = useCoffee();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 animate-bounce [animation-duration:1s]">
      <div className="bg-[#1c120a] text-[#fbf7f2] px-5 py-3 rounded-2xl shadow-2xl border border-[#5a331c] flex items-center gap-3">
        <div className="w-7 h-7 rounded-full bg-[#f4a261] text-[#1c120a] flex items-center justify-center shrink-0 font-bold">
          <Coffee className="w-4 h-4" />
        </div>
        <span className="text-xs sm:text-sm font-semibold">{toastMessage}</span>
        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
      </div>
    </div>
  );
};
