import React, { useState } from 'react';
import { COFFEE_BEANS } from '../data/coffeeData';
import { useCoffee } from '../context/CoffeeContext';
import { CoffeeBean } from '../types';
import { Flame, Star, Package, Check, Sparkles, RefreshCw } from 'lucide-react';

export const BeansRoasterySection: React.FC = () => {
  const { addBeanToCart } = useCoffee();
  
  // Track selected grind and subscription mode per bean
  const [grindSelections, setGrindSelections] = useState<Record<string, string>>({
    'bean-ethiopia-g1': 'Whole Bean',
    'bean-house-velvet': 'Whole Bean',
    'bean-colombia-san-agustin': 'Whole Bean',
    'bean-sumatra-mandheling': 'Whole Bean'
  });

  const [subscriptionModes, setSubscriptionModes] = useState<Record<string, boolean>>({
    'bean-ethiopia-g1': false,
    'bean-house-velvet': false,
    'bean-colombia-san-agustin': false,
    'bean-sumatra-mandheling': false
  });

  const [addedIds, setAddedIds] = useState<string[]>([]);

  const grindOptions = [
    'Whole Bean (Recommended)',
    'Espresso (Fine)',
    'Pour Over / V60 (Medium-Fine)',
    'Drip Machine (Medium)',
    'French Press / Cold Brew (Coarse)'
  ];

  const handleGrindChange = (beanId: string, grind: string) => {
    setGrindSelections(prev => ({ ...prev, [beanId]: grind }));
  };

  const toggleSub = (beanId: string) => {
    setSubscriptionModes(prev => ({ ...prev, [beanId]: !prev[beanId] }));
  };

  const handleAdd = (bean: CoffeeBean) => {
    const grind = grindSelections[bean.id] || 'Whole Bean';
    const isSub = subscriptionModes[bean.id] || false;
    addBeanToCart(bean, grind, isSub);

    setAddedIds(prev => [...prev, bean.id]);
    setTimeout(() => {
      setAddedIds(prev => prev.filter(id => id !== bean.id));
    }, 1400);
  };

  return (
    <section id="beans" className="py-20 bg-[#1a110a] text-[#fbf7f2] relative border-y border-[#341e12]">
      {/* Background glow */}
      <div className="absolute top-1/2 left-10 w-96 h-96 bg-[#9d6b38]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#361e12] text-[#f4a261] text-xs font-bold uppercase tracking-wider mb-3 border border-[#5d341f]">
            <Flame className="w-3.5 h-3.5 text-[#e76f51]" /> Fresh Batch Roasting Daily
          </div>
          <h2 className="font-serif-coffee text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#fbf7f2]">
            Take The Roastery Home
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#c7af9c] leading-relaxed">
            Every bag is small-batch flame roasted in our 15kg Giesen roaster, packed in nitrogen-flushed 
            compostable bags with one-way degassing valves to guarantee peak aroma for 60 days.
          </p>
        </div>

        {/* Beans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {COFFEE_BEANS.map(bean => {
            const isSub = subscriptionModes[bean.id] || false;
            const currentGrind = grindSelections[bean.id] || 'Whole Bean';
            const price = isSub ? Number((bean.price * 0.85).toFixed(2)) : bean.price;
            const isAdded = addedIds.includes(bean.id);

            return (
              <div
                key={bean.id}
                className="bg-[#241710] rounded-2xl overflow-hidden border border-[#482c1b] hover:border-[#8c582f] flex flex-col justify-between shadow-xl transition-all duration-300 hover:-translate-y-1 group"
              >
                <div>
                  {/* Bag Image container */}
                  <div className="relative h-60 overflow-hidden bg-[#180e08]">
                    <img
                      src={bean.image}
                      alt={bean.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#241710] via-transparent to-black/30" />

                    {/* Roast badge */}
                    <div className="absolute top-3 left-3 bg-[#18110b]/90 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-semibold text-[#f4a261] border border-[#522e1b] flex items-center gap-1.5">
                      <Flame className="w-3 h-3 text-[#e76f51]" />
                      <span>{bean.roastLevel}</span>
                    </div>

                    {/* SCA Score / Rating */}
                    <div className="absolute top-3 right-3 bg-[#18110b]/90 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-bold text-amber-400 flex items-center gap-1 border border-[#522e1b]">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>{bean.rating}</span>
                    </div>

                    {/* Origin pill */}
                    <div className="absolute bottom-3 left-3 right-3 text-xs text-[#d8c3b0] flex items-center justify-between">
                      <span className="font-medium text-[#e9c46a]">{bean.origin}</span>
                      <span className="text-[10px] text-[#a88a74]">{bean.altitude}</span>
                    </div>
                  </div>

                  {/* Content details */}
                  <div className="p-5 space-y-3">
                    <h3 className="font-serif-coffee text-lg sm:text-xl font-bold text-[#fbf7f2] leading-snug group-hover:text-[#f4a261] transition-colors">
                      {bean.name}
                    </h3>
                    
                    <p className="text-xs text-[#c5b09f] line-clamp-2">
                      {bean.description}
                    </p>

                    {/* Process Info */}
                    <div className="text-[11px] text-[#9c8473]">
                      <span className="text-[#d8c3b0] font-semibold">Process:</span> {bean.process}
                    </div>

                    {/* Tasting notes */}
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#a88261] block mb-1">
                        Tasting Profile:
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {bean.tastingNotes.map((note, i) => (
                          <span
                            key={i}
                            className="text-[11px] px-2 py-0.5 rounded bg-[#361e12] text-[#f4a261] border border-[#55301b]"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Grind Selector */}
                    <div className="pt-2">
                      <label className="text-[11px] font-semibold text-[#bfa48d] block mb-1">
                        Grind Size
                      </label>
                      <select
                        value={currentGrind}
                        onChange={(e) => handleGrindChange(bean.id, e.target.value)}
                        className="w-full text-xs bg-[#190f09] text-[#fbf7f2] rounded-lg px-2.5 py-2 border border-[#482b1b] focus:outline-none focus:ring-1 focus:ring-[#9d6b38]"
                      >
                        {grindOptions.map((g) => (
                          <option key={g} value={g}>
                            {g}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Subscription Toggle */}
                    <div
                      onClick={() => toggleSub(bean.id)}
                      className={`p-2.5 rounded-xl border cursor-pointer transition flex items-center justify-between text-xs ${
                        isSub
                          ? 'bg-[#3b2416] border-[#f4a261] text-[#fbf7f2]'
                          : 'bg-[#1a1009] border-[#382315] text-[#b89f8d] hover:border-[#5a3621]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <RefreshCw className={`w-3.5 h-3.5 ${isSub ? 'text-[#f4a261] animate-spin [animation-duration:8s]' : 'text-[#8c7462]'}`} />
                        <div>
                          <span className="font-semibold">Subscribe & Save 15%</span>
                          <span className="block text-[10px] text-[#9c8473]">Delivered fresh every 2 weeks</span>
                        </div>
                      </div>
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSub ? 'bg-[#f4a261] border-[#f4a261] text-[#1a110a]' : 'border-[#6c4832]'}`}>
                        {isSub && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                      </div>
                    </div>

                  </div>
                </div>

                {/* Bottom Card Footer */}
                <div className="p-5 pt-0 mt-2">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <div className="text-lg font-bold text-[#fbf7f2] font-serif-coffee">
                        ${price.toFixed(2)}
                      </div>
                      {isSub && (
                        <span className="text-[10px] text-[#e76f51] line-through mr-1">
                          ${bean.price.toFixed(2)}
                        </span>
                      )}
                      <span className="text-[10px] text-[#9c8473]">340g / 12 oz</span>
                    </div>

                    <button
                      onClick={() => handleAdd(bean)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                        isAdded
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[#c59b6d] hover:bg-[#d4a373] text-[#1a110a] active:scale-95'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Added!</span>
                        </>
                      ) : (
                        <>
                          <Package className="w-3.5 h-3.5" />
                          <span>Add Bag</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Roaster Quality Guarantee */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div className="p-6 rounded-2xl bg-[#22160e] border border-[#3d2416]">
            <Package className="w-8 h-8 text-[#f4a261] mx-auto mb-2" />
            <h4 className="font-bold text-sm text-[#fbf7f2]">Degassing Valve Pouch</h4>
            <p className="text-xs text-[#a88f7c] mt-1">Preserves freshly roasted aromatic oils while releasing natural CO₂ gas.</p>
          </div>
          <div className="p-6 rounded-2xl bg-[#22160e] border border-[#3d2416]">
            <Sparkles className="w-8 h-8 text-[#f4a261] mx-auto mb-2" />
            <h4 className="font-bold text-sm text-[#fbf7f2]">Precision Roast Curves</h4>
            <p className="text-xs text-[#a88f7c] mt-1">Computer-profiled roast development to unlock natural terroir sweetness.</p>
          </div>
          <div className="p-6 rounded-2xl bg-[#22160e] border border-[#3d2416]">
            <Flame className="w-8 h-8 text-[#f4a261] mx-auto mb-2" />
            <h4 className="font-bold text-sm text-[#fbf7f2]">Free Local Delivery</h4>
            <p className="text-xs text-[#a88f7c] mt-1">Complimentary roasted bean doorstep delivery in Portland metro on 2+ bags.</p>
          </div>
        </div>

      </div>
    </section>
  );
};
