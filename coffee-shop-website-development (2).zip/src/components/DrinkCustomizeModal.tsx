import React, { useState, useEffect } from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { CustomizationOptions } from '../types';
import { X, Check, Flame, Star, Coffee, Sparkles } from 'lucide-react';

export const DrinkCustomizeModal: React.FC = () => {
  const { customizingItem, closeCustomizer, addToCart } = useCoffee();

  const [size, setSize] = useState<'8oz' | '12oz' | '16oz'>('12oz');
  const [temperature, setTemperature] = useState<'Hot' | 'Iced'>('Hot');
  const [milk, setMilk] = useState<CustomizationOptions['milk']>('Whole Milk');
  const [sweetness, setSweetness] = useState<CustomizationOptions['sweetness']>('50% (Standard)');
  const [iceLevel, setIceLevel] = useState<CustomizationOptions['iceLevel']>('Regular Ice');
  const [extras, setExtras] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (customizingItem) {
      setSize('12oz');
      setTemperature(customizingItem.category === 'cold-brew' ? 'Iced' : 'Hot');
      setMilk(customizingItem.name.toLowerCase().includes('oat') ? 'Oat Milk (+0.75)' : 'Whole Milk');
      setSweetness('50% (Standard)');
      setIceLevel(customizingItem.category === 'cold-brew' ? 'Regular Ice' : 'Regular Ice');
      setExtras([]);
      setNotes('');
      setQuantity(1);
    }
  }, [customizingItem]);

  if (!customizingItem) return null;

  // Calculate live price
  let calculatedUnit = customizingItem.price;
  if (size === '16oz') calculatedUnit += 0.85;
  if (size === '8oz') calculatedUnit = Math.max(customizingItem.price - 0.40, 3.50);
  if (milk.includes('+0.75')) calculatedUnit += 0.75;
  if (extras.includes('Extra Double Shot')) calculatedUnit += 1.25;
  if (extras.includes('Madagascar Vanilla Bean')) calculatedUnit += 0.80;
  if (extras.includes('Salted Caramel Drizzle')) calculatedUnit += 0.65;
  if (extras.includes('Oat Cold Foam')) calculatedUnit += 1.20;

  const totalPrice = (calculatedUnit * quantity).toFixed(2);

  const toggleExtra = (extraName: string) => {
    setExtras(prev =>
      prev.includes(extraName) ? prev.filter(e => e !== extraName) : [...prev, extraName]
    );
  };

  const handleConfirm = () => {
    addToCart(
      customizingItem,
      {
        size,
        temperature,
        milk,
        sweetness,
        iceLevel: temperature === 'Iced' ? iceLevel : undefined,
        extras,
        notes
      },
      quantity
    );
    closeCustomizer();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-[#faf6f0] text-[#2b1f17] rounded-3xl max-w-xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-[#dbc6b2] overflow-hidden animate-scaleIn"
        onClick={e => e.stopPropagation()}
      >
        {/* Header with image */}
        <div className="relative h-44 sm:h-52 shrink-0 overflow-hidden bg-[#241710]">
          <img
            src={customizingItem.image}
            alt={customizingItem.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1b110a] via-black/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={closeCustomizer}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Title info in header */}
          <div className="absolute bottom-3 left-4 right-4 text-white">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#e76f51] text-white">
                {customizingItem.category}
              </span>
              <div className="flex items-center text-amber-400 text-xs">
                <Star className="w-3.5 h-3.5 fill-amber-400 mr-1" />
                <span>{customizingItem.rating} ({customizingItem.reviewsCount})</span>
              </div>
            </div>
            <h3 className="font-serif-coffee text-xl sm:text-2xl font-bold leading-tight">
              {customizingItem.name}
            </h3>
          </div>
        </div>

        {/* Scrollable Customization Options */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
          
          {/* Size Choice */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-2.5">
              1. Select Drink Size
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { id: '8oz', label: '8 oz Small', note: '-$0.40' },
                { id: '12oz', label: '12 oz Standard', note: 'Regular' },
                { id: '16oz', label: '16 oz Large', note: '+$0.85' },
              ].map(opt => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setSize(opt.id as any)}
                  className={`p-3 rounded-xl border text-center transition ${
                    size === opt.id
                      ? 'bg-[#2b1b11] text-[#fbf7f2] border-[#2b1b11] shadow-md'
                      : 'bg-white text-[#5c4637] border-[#e2d2c2] hover:bg-[#f5ede4]'
                  }`}
                >
                  <div className="text-sm font-bold">{opt.id}</div>
                  <div className={`text-[11px] ${size === opt.id ? 'text-[#e9c46a]' : 'text-[#8b7566]'}`}>
                    {opt.note}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Temperature */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-2.5">
              2. Temperature
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { id: 'Hot', label: 'Steamed Hot', desc: 'Silky microfoam 145°F', icon: Flame },
                { id: 'Iced', label: 'Over Craft Ice', desc: 'Chilled over crystal cubes', icon: Coffee },
              ].map(opt => {
                const Icon = opt.icon;
                const isSelected = temperature === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setTemperature(opt.id as any)}
                    className={`p-3 rounded-xl border flex items-center gap-3 text-left transition ${
                      isSelected
                        ? 'bg-[#2b1b11] text-[#fbf7f2] border-[#2b1b11] shadow-md'
                        : 'bg-white text-[#5c4637] border-[#e2d2c2] hover:bg-[#f5ede4]'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isSelected ? 'text-[#f4a261]' : 'text-[#8c7462]'}`} />
                    <div>
                      <div className="text-sm font-bold">{opt.label}</div>
                      <div className={`text-[11px] ${isSelected ? 'text-[#d8c3b0]' : 'text-[#8c7462]'}`}>
                        {opt.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Ice Level (if iced) */}
          {temperature === 'Iced' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-2">
                Ice Level
              </label>
              <div className="grid grid-cols-4 gap-2">
                {['None', 'Light Ice', 'Regular Ice', 'Extra Ice'].map(ice => (
                  <button
                    key={ice}
                    type="button"
                    onClick={() => setIceLevel(ice as any)}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border text-center transition ${
                      iceLevel === ice
                        ? 'bg-[#3b2416] text-[#fbf7f2] border-[#3b2416]'
                        : 'bg-white text-[#5c4637] border-[#e2d2c2]'
                    }`}
                  >
                    {ice}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Milk Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-2.5">
              3. Choice of Milk / Base
            </label>
            <div className="space-y-1.5">
              {[
                { id: 'Whole Milk', label: 'Organic Creamery Whole Milk', price: 'Included' },
                { id: 'Oat Milk (+0.75)', label: 'Oatly Barista Edition (Steams Great)', price: '+$0.75' },
                { id: 'Almond Milk (+0.75)', label: 'Califia Organic Almond Milk', price: '+$0.75' },
                { id: 'Coconut Milk (+0.75)', label: 'Unsweetened Creamy Coconut Milk', price: '+$0.75' },
                { id: 'None (Black)', label: 'Black (No Milk / Straight Brew)', price: 'Free' },
              ].map(m => (
                <label
                  key={m.id}
                  className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition ${
                    milk === m.id
                      ? 'bg-[#efe4d8] border-[#9d6b38] font-bold text-[#2b1b11]'
                      : 'bg-white border-[#e6d8cb] text-[#554133] hover:bg-[#fbf7f2]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 text-xs sm:text-sm">
                    <input
                      type="radio"
                      name="milk"
                      checked={milk === m.id}
                      onChange={() => setMilk(m.id as any)}
                      className="accent-[#9d6b38]"
                    />
                    <span>{m.label}</span>
                  </div>
                  <span className="text-xs text-[#8c6b52] font-semibold">{m.price}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Sweetness Slider/Buttons */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-2.5">
              4. Sweetness Level
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                '0% (Unsweetened)',
                '25% (Hint of Sweet)',
                '50% (Standard)',
                '100% (Extra Sweet)',
              ].map(sw => (
                <button
                  key={sw}
                  type="button"
                  onClick={() => setSweetness(sw as any)}
                  className={`p-2 rounded-lg text-xs font-medium border text-center transition ${
                    sweetness === sw
                      ? 'bg-[#2b1b11] text-[#fbf7f2] border-[#2b1b11]'
                      : 'bg-white text-[#5c4637] border-[#e2d2c2] hover:bg-[#f5ede4]'
                  }`}
                >
                  {sw}
                </button>
              ))}
            </div>
          </div>

          {/* Artisanal Additions */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-2.5">
              5. Handcrafted Additions (Optional)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { name: 'Extra Double Shot', price: '+$1.25' },
                { name: 'Madagascar Vanilla Bean', price: '+$0.80' },
                { name: 'Salted Caramel Drizzle', price: '+$0.65' },
                { name: 'Oat Cold Foam', price: '+$1.20' },
                { name: 'Ceylon Cinnamon Dust', price: 'Free' },
              ].map(add => {
                const isSelected = extras.includes(add.name);
                return (
                  <button
                    key={add.name}
                    type="button"
                    onClick={() => toggleExtra(add.name)}
                    className={`p-2.5 rounded-xl border flex items-center justify-between text-left text-xs transition ${
                      isSelected
                        ? 'bg-[#eadaaa]/40 border-[#b88c4d] text-[#2b1b11] font-semibold'
                        : 'bg-white border-[#e6d8cb] text-[#554133]'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSelected ? 'bg-[#9d6b38] border-[#9d6b38] text-white' : 'border-[#b59e8c]'}`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span>{add.name}</span>
                    </div>
                    <span className="text-[#8c6b52] font-semibold">{add.price}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Special Requests */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#735845] mb-1.5">
              Barista Instructions
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Extra hot, pour into my own reusable tumbler, etc."
              className="w-full px-3.5 py-2.5 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17] placeholder-[#a69282] focus:outline-none focus:ring-2 focus:ring-[#9d6b38]"
            />
          </div>

        </div>

        {/* Modal Footer with quantity & checkout button */}
        <div className="p-4 sm:p-5 bg-white border-t border-[#e8dacf] flex items-center justify-between gap-4 shrink-0">
          {/* Quantity stepper */}
          <div className="flex items-center border border-[#d8c7b8] rounded-xl overflow-hidden bg-[#faf6f0]">
            <button
              onClick={() => setQuantity(q => Math.max(1, q - 1))}
              className="px-3.5 py-2 hover:bg-[#ebdccf] text-[#2b1f17] font-bold text-base transition"
            >
              -
            </button>
            <span className="px-3 font-bold text-sm text-[#2b1f17]">{quantity}</span>
            <button
              onClick={() => setQuantity(q => q + 1)}
              className="px-3.5 py-2 hover:bg-[#ebdccf] text-[#2b1f17] font-bold text-base transition"
            >
              +
            </button>
          </div>

          {/* Add to Cart button */}
          <button
            onClick={handleConfirm}
            className="flex-1 py-3 px-5 rounded-xl bg-gradient-to-r from-[#9d6b38] to-[#7d4e2d] hover:from-[#af773f] hover:to-[#8c5732] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-[#9d6b38]/20 transition"
          >
            <Sparkles className="w-4 h-4 text-[#f4a261]" />
            <span>Add to Order • ${totalPrice}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
