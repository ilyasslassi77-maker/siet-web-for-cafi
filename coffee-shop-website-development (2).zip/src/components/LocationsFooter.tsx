import React, { useState } from 'react';
import { CAFE_LOCATIONS } from '../data/coffeeData';
import { useCoffee } from '../context/CoffeeContext';
import { 
  Coffee, 
  MapPin, 
  Clock, 
  Phone, 
  Mail, 
  Check, 
  Calendar,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const LocationsFooter: React.FC = () => {
  const { setIsReservationOpen, showToast } = useCoffee();
  const [email, setEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setNewsletterSubscribed(true);
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.8 }
      });
    } catch {
      // ignore
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText('FIRSTCUP');
    setCopiedCode(true);
    showToast('Promo code FIRSTCUP copied to clipboard!');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <footer id="locations" className="bg-[#120c08] text-[#fbf7f2] pt-20 pb-12 border-t border-[#2e1a0f]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#2a170d] text-[#f4a261] text-xs font-bold uppercase tracking-wider mb-3 border border-[#482816]">
            <MapPin className="w-3.5 h-3.5 text-[#e76f51]" /> Find Your Sanctuary
          </div>
          <h2 className="font-serif-coffee text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#fbf7f2]">
            Our Cafe Locations & Hours
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#c0a894] leading-relaxed">
            Come smell the fresh roast, listen to curated vinyl records, and let our baristas craft your morning.
          </p>
        </div>

        {/* 2 Locations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {CAFE_LOCATIONS.map(loc => (
            <div
              key={loc.id}
              className="bg-[#1c120b] rounded-3xl p-7 sm:p-8 border border-[#3e2314] hover:border-[#734323] transition-all space-y-6 shadow-xl"
            >
              <div className="flex justify-between items-start">
                <div>
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full bg-[#203a27] text-emerald-400 border border-[#2d5637] mb-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    {loc.status}
                  </span>
                  <h3 className="font-serif-coffee text-2xl font-bold text-[#fbf7f2]">
                    {loc.name}
                  </h3>
                </div>

                <button
                  onClick={() => setIsReservationOpen(true)}
                  className="px-3 py-1.5 rounded-full text-xs font-semibold bg-[#2e190e] hover:bg-[#422415] text-[#f4a261] border border-[#5a331c] flex items-center gap-1 transition"
                >
                  <Calendar className="w-3 h-3" />
                  <span>Reserve</span>
                </button>
              </div>

              {/* Address and Contact list */}
              <div className="space-y-3 text-xs sm:text-sm text-[#d4bca9]">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#c59b6d] shrink-0 mt-0.5" />
                  <div>
                    <div>{loc.address}</div>
                    <div className="text-[11px] text-[#9c8473]">{loc.city}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-[#c59b6d] shrink-0" />
                  <span>{loc.hours}</span>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-[#c59b6d] shrink-0" />
                  <span>{loc.phone}</span>
                </div>
              </div>

              {/* Features chips */}
              <div className="pt-3 border-t border-[#2e1a0f] flex flex-wrap gap-1.5">
                {loc.features.map((feat, i) => (
                  <span
                    key={i}
                    className="text-[10px] px-2.5 py-1 rounded-md bg-[#25170f] text-[#c5a386] border border-[#3e2416]"
                  >
                    ✓ {feat}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Newsletter Signup Card */}
        <div className="bg-gradient-to-r from-[#24150c] via-[#2d1b10] to-[#1e1109] rounded-3xl p-8 sm:p-12 border border-[#482816] text-center max-w-4xl mx-auto mb-20 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#e76f51]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#3e2112] text-[#f4a261] mx-auto flex items-center justify-center">
              <Mail className="w-6 h-6" />
            </div>

            <h3 className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#fbf7f2]">
              Join The Roaster's Guild
            </h3>
            
            <p className="text-xs sm:text-sm text-[#d4bca9]">
              Receive secret micro-lot drops, Saturday cupping invitations, and home brew guides. 
              Enjoy <strong>20% off</strong> your first online order.
            </p>

            {newsletterSubscribed ? (
              <div className="bg-[#1c120a] p-5 rounded-2xl border border-[#522d17] space-y-2 animate-fadeIn">
                <div className="flex items-center justify-center gap-2 text-emerald-400 text-sm font-bold">
                  <Check className="w-4 h-4" /> You're on the list!
                </div>
                <p className="text-xs text-[#d8c3b0]">
                  Use promo code at checkout:
                </p>
                <div className="inline-flex items-center gap-2 bg-[#2d180d] px-4 py-2 rounded-xl border border-[#6b3b1f]">
                  <span className="font-mono font-bold text-[#f4a261] text-base tracking-wider">FIRSTCUP</span>
                  <button
                    onClick={copyCode}
                    className="text-xs text-[#e8dacb] hover:text-white underline font-semibold ml-2"
                  >
                    {copiedCode ? 'Copied!' : 'Copy Code'}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleNewsletter} className="flex flex-col sm:flex-row gap-2.5 max-w-md mx-auto pt-2">
                <input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  className="flex-1 px-4 py-3 rounded-xl bg-[#140b07] border border-[#482816] text-xs sm:text-sm text-[#fbf7f2] placeholder-[#8a705e] focus:outline-none focus:ring-2 focus:ring-[#9d6b38]"
                />
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-[#c59b6d] hover:bg-[#d4a373] text-[#140b07] font-bold text-xs sm:text-sm transition flex items-center justify-center gap-1.5"
                >
                  <span>Subscribe</span>
                  <Sparkles className="w-4 h-4 text-[#140b07]" />
                </button>
              </form>
            )}

            <span className="block text-[11px] text-[#8c7462]">
              No spam, ever. Unsubscribe with 1-click anytime.
            </span>
          </div>
        </div>

        {/* Footer Bottom Bar */}
        <div className="pt-8 border-t border-[#2a170d] flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-[#8c7462]">
          
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#2e190e] text-[#f4a261] flex items-center justify-center font-bold">
              <Coffee className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-[#fbf7f2] text-sm font-serif-coffee">TERRA & ROAST</span>
              <span className="block text-[10px] text-[#735d4e]">Specialty Coffee Roasting Co. © 2026</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6">
            <a href="#menu" className="hover:text-[#f4a261] transition">Cafe Menu</a>
            <a href="#beans" className="hover:text-[#f4a261] transition">Coffee Beans</a>
            <a href="#brewing" className="hover:text-[#f4a261] transition">Brew Ratio Lab</a>
            <a href="#story" className="hover:text-[#f4a261] transition">Farm Direct</a>
            <button onClick={() => setIsReservationOpen(true)} className="hover:text-[#f4a261] transition">Bookings</button>
          </div>

          <div className="flex items-center gap-4 text-[#b89574]">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram" className="hover:text-[#fbf7f2] transition flex items-center gap-1">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
              <span className="text-[11px]">@terra.roast</span>
            </a>
            <span className="flex items-center gap-1 text-[11px]">
              Crafted with <Coffee className="w-3 h-3 text-[#f4a261] inline" /> & intention
            </span>
          </div>

        </div>

      </div>
    </footer>
  );
};
