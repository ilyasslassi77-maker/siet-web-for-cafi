import React, { useState } from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  Clock, 
  MapPin, 
  Tag, 
  Check, 
  HeartHandshake,
  Coffee
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const CartDrawer: React.FC = () => {
  const { 
    cart, 
    cartCount, 
    cartSubtotal, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    isCartOpen, 
    setIsCartOpen,
    setActiveOrder
  } = useCoffee();

  const [fulfillment, setFulfillment] = useState<'pickup' | 'delivery'>('pickup');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [tipPercent, setTipPercent] = useState<number>(15);
  const [promoCode, setPromoCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [promoSuccessMsg, setPromoSuccessMsg] = useState('');
  const [promoError, setPromoError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCartOpen) return null;

  const handleApplyPromo = () => {
    setPromoError('');
    setPromoSuccessMsg('');
    const code = promoCode.trim().toUpperCase();

    if (code === 'FIRSTCUP') {
      setAppliedDiscount(0.20); // 20%
      setPromoSuccessMsg('Promo applied: 20% off your first coffee ritual!');
    } else if (code === 'ROAST10') {
      setAppliedDiscount(0.10); // 10%
      setPromoSuccessMsg('Promo applied: 10% roastery discount!');
    } else {
      setPromoError('Invalid code. Try using FIRSTCUP for 20% off!');
    }
  };

  const discountAmount = Number((cartSubtotal * appliedDiscount).toFixed(2));
  const discountedSubtotal = Math.max(0, cartSubtotal - discountAmount);
  const tipAmount = tipPercent > 0 ? Number(((discountedSubtotal * tipPercent) / 100).toFixed(2)) : 0;
  const deliveryFee = fulfillment === 'delivery' ? 3.99 : 0;
  const taxAmount = Number(((discountedSubtotal + deliveryFee) * 0.0825).toFixed(2));
  const finalTotal = Number((discountedSubtotal + tipAmount + deliveryFee + taxAmount).toFixed(2));

  const handleCheckout = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsCartOpen(false);
      
      const orderId = `TR-${Math.floor(100000 + Math.random() * 900000)}`;
      setActiveOrder({
        orderId,
        items: [...cart],
        total: finalTotal,
        pickupTime: fulfillment === 'pickup' ? '12 - 15 minutes' : '30 - 40 minutes',
        fulfillmentType: fulfillment,
        address: fulfillment === 'delivery' ? deliveryAddress || '742 Evergreen Terrace, Portland' : undefined
      });

      clearCart();

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.5 }
        });
      } catch {
        // ignore
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="absolute inset-y-0 right-0 max-w-full flex pl-10"
        onClick={e => e.stopPropagation()}
      >
        <div className="w-screen max-w-md bg-[#faf6f0] text-[#2b1f17] shadow-2xl flex flex-col justify-between border-l border-[#decbb7]">
          
          {/* Header */}
          <div className="p-5 sm:p-6 bg-white border-b border-[#ebdacf] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#2b1b11] text-[#f4a261] flex items-center justify-center">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-serif-coffee text-xl font-bold text-[#1f140e]">
                  Your Coffee Order
                </h3>
                <span className="text-xs text-[#8c7462] font-medium">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'} in basket
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsCartOpen(false)}
              aria-label="Close Cart"
              className="p-2 rounded-full text-[#8c7462] hover:bg-[#f3e6d8] transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body items scroll area */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
            
            {/* Fulfillment Mode Toggle */}
            <div className="bg-[#ede1d5]/60 p-1 rounded-xl grid grid-cols-2 gap-1 text-xs font-bold">
              <button
                type="button"
                onClick={() => setFulfillment('pickup')}
                className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition ${
                  fulfillment === 'pickup'
                    ? 'bg-[#2b1b11] text-[#fbf7f2] shadow'
                    : 'text-[#6f5644] hover:text-[#2b1f17]'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-[#f4a261]" />
                <span>Pickup (Ready in 12m)</span>
              </button>
              <button
                type="button"
                onClick={() => setFulfillment('delivery')}
                className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition ${
                  fulfillment === 'delivery'
                    ? 'bg-[#2b1b11] text-[#fbf7f2] shadow'
                    : 'text-[#6f5644] hover:text-[#2b1f17]'
                }`}
              >
                <MapPin className="w-3.5 h-3.5 text-[#f4a261]" />
                <span>Local Delivery ($3.99)</span>
              </button>
            </div>

            {fulfillment === 'pickup' ? (
              <div className="text-[11px] text-[#785f4e] bg-[#f5ece1] p-3 rounded-xl border border-[#e4d3c3] flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#9d6b38] shrink-0" />
                <span>Pickup from: <strong>Flagship Roastery (428 Timber & Stone Way)</strong></span>
              </div>
            ) : (
              <div className="space-y-1">
                <label className="text-[11px] font-bold uppercase text-[#735845]">Delivery Address</label>
                <input
                  type="text"
                  placeholder="Street address, Portland OR"
                  value={deliveryAddress}
                  onChange={e => setDeliveryAddress(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl bg-white border border-[#e2d5c7] text-[#2b1f17]"
                />
              </div>
            )}

            {/* Empty Cart Message */}
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <div className="w-16 h-16 rounded-full bg-[#f1e4d6] text-[#9d6b38] flex items-center justify-center mx-auto">
                  <Coffee className="w-8 h-8" />
                </div>
                <h4 className="font-serif-coffee text-lg font-bold text-[#2b1f17]">Your basket is feeling empty</h4>
                <p className="text-xs text-[#7e6858] max-w-xs mx-auto">
                  Treat yourself to a velvety flat white, fresh honey lavender latte, or fresh roasted single-origin bag.
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="mt-2 px-5 py-2.5 rounded-full bg-[#2b1b11] text-[#fbf7f2] text-xs font-bold hover:bg-[#3d2417] transition"
                >
                  Browse Roastery Menu
                </button>
              </div>
            ) : (
              /* Item list */
              <div className="space-y-3">
                {cart.map((ci) => (
                  <div
                    key={ci.cartItemId}
                    className="bg-white p-3.5 rounded-2xl border border-[#ebdacf] shadow-sm flex gap-3 relative group"
                  >
                    <img
                      src={ci.item.image}
                      alt={ci.item.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0 bg-[#ebdccf]"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start gap-1">
                        <h4 className="text-sm font-bold text-[#1e130c] truncate">
                          {ci.item.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(ci.cartItemId)}
                          aria-label="Remove item"
                          className="text-[#a68c78] hover:text-[#d94848] transition p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Customization pills */}
                      <div className="text-[11px] text-[#7d6655] mt-1 space-y-0.5">
                        {ci.options.grindSize ? (
                          <div className="font-medium text-[#9d6b38]">{ci.options.grindSize}</div>
                        ) : (
                          <div>
                            <span>{ci.options.size}</span> • <span>{ci.options.temperature}</span> • <span>{ci.options.milk.split(' (')[0]}</span>
                          </div>
                        )}

                        {ci.options.extras && ci.options.extras.length > 0 && (
                          <div className="text-[10px] text-[#a88261] truncate">
                            +{ci.options.extras.join(', ')}
                          </div>
                        )}
                        {ci.options.notes && (
                          <div className="italic text-[10px] text-[#8c7462]">
                            "{ci.options.notes}"
                          </div>
                        )}
                      </div>

                      {/* Price and quantity row */}
                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#f4ebe2]">
                        <span className="text-xs font-bold text-[#1e130c]">
                          ${(ci.unitPrice * ci.quantity).toFixed(2)}
                          {ci.quantity > 1 && (
                            <span className="text-[10px] text-[#8c7462] font-normal ml-1">
                              (${ci.unitPrice.toFixed(2)} ea)
                            </span>
                          )}
                        </span>

                        <div className="flex items-center border border-[#d8c7b8] rounded-lg overflow-hidden bg-[#faf6f0] text-xs">
                          <button
                            onClick={() => updateQuantity(ci.cartItemId, -1)}
                            className="px-2 py-0.5 hover:bg-[#ebdccf] font-bold text-[#2b1f17]"
                          >
                            -
                          </button>
                          <span className="px-2 font-bold">{ci.quantity}</span>
                          <button
                            onClick={() => updateQuantity(ci.cartItemId, 1)}
                            className="px-2 py-0.5 hover:bg-[#ebdccf] font-bold text-[#2b1f17]"
                          >
                            +
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>
                ))}

                {/* Promo Code Input */}
                <div className="pt-2">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#9c8473]" />
                      <input
                        type="text"
                        placeholder="Promo code (try FIRSTCUP)"
                        value={promoCode}
                        onChange={e => setPromoCode(e.target.value)}
                        className="w-full pl-8 pr-3 py-2 rounded-xl bg-white border border-[#e2d5c7] text-xs text-[#2b1f17] uppercase tracking-wider"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleApplyPromo}
                      className="px-3.5 py-2 rounded-xl bg-[#2b1b11] hover:bg-[#3d2417] text-[#fbf7f2] text-xs font-bold transition"
                    >
                      Apply
                    </button>
                  </div>
                  {promoSuccessMsg && (
                    <p className="text-[11px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
                      <Check className="w-3 h-3" /> {promoSuccessMsg}
                    </p>
                  )}
                  {promoError && (
                    <p className="text-[11px] text-[#d94848] font-medium mt-1">
                      {promoError}
                    </p>
                  )}
                </div>

                {/* Barista Tip Selector */}
                <div className="p-3.5 rounded-2xl bg-white border border-[#ebdacf] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-[#1e130c] flex items-center gap-1.5">
                      <HeartHandshake className="w-4 h-4 text-[#e76f51]" /> Support Our Craft Baristas
                    </span>
                    <span className="text-[#8c7462] font-semibold">${tipAmount.toFixed(2)}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[0, 15, 18, 20].map(p => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setTipPercent(p)}
                        className={`py-1.5 text-xs rounded-lg font-bold border transition ${
                          tipPercent === p
                            ? 'bg-[#2b1b11] text-[#fbf7f2] border-[#2b1b11]'
                            : 'bg-[#faf6f0] text-[#6d5543] border-[#e2d5c7] hover:bg-[#ede0d2]'
                        }`}
                      >
                        {p === 0 ? 'No Tip' : `${p}%`}
                      </button>
                    ))}
                  </div>
                </div>

              </div>
            )}

          </div>

          {/* Footer Checkout Summary */}
          {cart.length > 0 && (
            <div className="p-5 sm:p-6 bg-white border-t border-[#ebdacf] space-y-3">
              {/* Line items */}
              <div className="space-y-1.5 text-xs text-[#735e50]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-[#1e130c]">${cartSubtotal.toFixed(2)}</span>
                </div>

                {appliedDiscount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-medium">
                    <span>Discount ({(appliedDiscount * 100).toFixed(0)}% Off)</span>
                    <span>-${discountAmount.toFixed(2)}</span>
                  </div>
                )}

                {fulfillment === 'delivery' && (
                  <div className="flex justify-between">
                    <span>Local Courier Delivery</span>
                    <span>$3.99</span>
                  </div>
                )}

                {tipAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Barista Tip ({tipPercent}%)</span>
                    <span>${tipAmount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Estimated Tax (8.25%)</span>
                  <span>${taxAmount.toFixed(2)}</span>
                </div>

                <div className="flex justify-between text-sm sm:text-base font-bold text-[#1e130c] pt-2 border-t border-[#f0e4d7]">
                  <span>Total Amount</span>
                  <span className="font-serif-coffee text-lg sm:text-xl text-[#9d6b38]">
                    ${finalTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Checkout button */}
              <button
                type="button"
                disabled={isSubmitting}
                onClick={handleCheckout}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-[#9d6b38] to-[#7d4e2d] hover:from-[#af773f] hover:to-[#8c5732] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-[#9d6b38]/25 transition disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Securing Order...</span>
                ) : (
                  <>
                    <span>Place Order • ${finalTotal.toFixed(2)}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center">
                <span className="text-[10px] text-[#9c8473]">
                  🔒 Express 256-Bit SSL Checkout • Apple Pay & Google Pay Supported
                </span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
