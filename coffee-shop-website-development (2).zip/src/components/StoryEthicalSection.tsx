import React from 'react';
import { ShieldCheck, Leaf, Globe, Flame, Award, Heart } from 'lucide-react';

export const StoryEthicalSection: React.FC = () => {
  return (
    <section id="story" className="py-20 bg-[#160f09] text-[#fbf7f2] relative border-b border-[#361f12]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#321c10] text-[#f4a261] text-xs font-bold uppercase tracking-wider mb-3 border border-[#5a331c]">
            <Globe className="w-3.5 h-3.5 text-[#e76f51]" /> Farm-to-Cup Transparency
          </div>
          <h2 className="font-serif-coffee text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#fbf7f2]">
            Grown With Dignity. Roasted With Care.
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#c7af9c] leading-relaxed">
            Coffee is not a commodity—it is the fruit of generational craftsmanship. We travel directly to origin, 
            paying 40% to 150% above Fair Trade minimums directly to farming families.
          </p>
        </div>

        {/* 3 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          
          <div className="bg-[#21150e] p-7 rounded-3xl border border-[#432717] hover:border-[#8c582f] transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#361f12] text-[#e9c46a] flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-serif-coffee text-xl font-bold text-[#fbf7f2]">
              Direct Estate Partnerships
            </h3>
            <p className="text-xs sm:text-sm text-[#bda795] leading-relaxed">
              We contract with 12 smallholder producers in Ethiopia, Colombia, Guatemala, and Sumatra. 
              By cutting out middlemen, farmers receive guaranteed livable income regardless of volatile Wall Street coffee futures.
            </p>
          </div>

          <div className="bg-[#21150e] p-7 rounded-3xl border border-[#432717] hover:border-[#8c582f] transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#361f12] text-[#2a9d8f] flex items-center justify-center">
              <Leaf className="w-6 h-6" />
            </div>
            <h3 className="font-serif-coffee text-xl font-bold text-[#fbf7f2]">
              Zero-Waste & Compostable
            </h3>
            <p className="text-xs sm:text-sm text-[#bda795] leading-relaxed">
              100% of our cafe to-go cups, lids, and straws are certified commercially compostable made from plants. 
              Our coffee chaff is donated locally to urban soil regeneration gardens.
            </p>
          </div>

          <div className="bg-[#21150e] p-7 rounded-3xl border border-[#432717] hover:border-[#8c582f] transition-all space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#361f12] text-[#e76f51] flex items-center justify-center">
              <Flame className="w-6 h-6" />
            </div>
            <h3 className="font-serif-coffee text-xl font-bold text-[#fbf7f2]">
              Convection Flame Roasting
            </h3>
            <p className="text-xs sm:text-sm text-[#bda795] leading-relaxed">
              We roast on a cast-iron drum Giesen roaster using customized heat-transfer algorithms. 
              We never over-roast or mask the bean with dark carbon bitterness—allowing the floral jasmine and stone fruit terroir to emerge.
            </p>
          </div>

        </div>

        {/* Feature Split Banner */}
        <div className="bg-gradient-to-r from-[#2a170d] to-[#1a0e08] rounded-3xl overflow-hidden border border-[#522f1a] grid grid-cols-1 lg:grid-cols-2 items-center">
          <div className="p-8 sm:p-12 space-y-5">
            <div className="flex items-center gap-2 text-xs font-bold text-[#f4a261] uppercase tracking-wider">
              <Award className="w-4 h-4 text-[#e9c46a]" /> 2026 Micro-Lot Harvest
            </div>
            <h3 className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#fbf7f2]">
              "When you know the hands that picked the cherry, coffee becomes reverence."
            </h3>
            <p className="text-xs sm:text-sm text-[#d4bca9] leading-relaxed">
              Every morning at 6:00 AM, our head roasters taste and calibrate espresso extractions against water hardness and barometric pressure. 
              Because your morning ritual deserves perfection.
            </p>
            <div className="pt-2 flex items-center gap-4 text-xs text-[#a88a75]">
              <span className="flex items-center gap-1.5 font-medium text-[#fbf7f2]">
                <Heart className="w-4 h-4 text-[#e76f51] fill-[#e76f51]" /> 12,000+ happy morning rituals served monthly
              </span>
            </div>
          </div>

          <div className="h-64 sm:h-80 lg:h-full relative overflow-hidden bg-[#241710]">
            <img
              src="https://images.pexels.com/photos/26711782/pexels-photo-26711782.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
              alt="Artisan coffee hand drip filter preparation"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#1a0e08] via-transparent to-transparent lg:block hidden" />
          </div>
        </div>

      </div>
    </section>
  );
};
