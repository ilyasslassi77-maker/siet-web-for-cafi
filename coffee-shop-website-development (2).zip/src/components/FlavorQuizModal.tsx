import React, { useState } from 'react';
import { useCoffee } from '../context/CoffeeContext';
import { COFFEE_QUIZ_QUESTIONS, MENU_ITEMS } from '../data/coffeeData';
import { CoffeeItem } from '../types';
import { X, Sparkles, ArrowRight, RotateCcw, Check, Coffee } from 'lucide-react';

export const FlavorQuizModal: React.FC = () => {
  const { isQuizOpen, setIsQuizOpen, addToCart, openCustomizer } = useCoffee();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [recommendedDrink, setRecommendedDrink] = useState<CoffeeItem | null>(null);

  if (!isQuizOpen) return null;

  const handleSelectOption = (questionId: string, value: string) => {
    const updated = { ...answers, [questionId]: value };
    setAnswers(updated);

    if (currentStep < COFFEE_QUIZ_QUESTIONS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      // Calculate matching drink
      calculateRecommendation(updated);
    }
  };

  const calculateRecommendation = (finalAnswers: Record<string, string>) => {
    const milk = finalAnswers.milk_preference;
    const flavor = finalAnswers.flavor_profile;

    let matched: CoffeeItem | undefined;

    if (milk === 'iced') {
      if (flavor === 'rich' || flavor === 'nutty') {
        matched = MENU_ITEMS.find(m => m.id === 'cb-caramel-cloud') || MENU_ITEMS[0];
      } else if (flavor === 'botanical' || flavor === 'fruity') {
        matched = MENU_ITEMS.find(m => m.id === 'cb-tonic-citrus') || MENU_ITEMS[2];
      } else {
        matched = MENU_ITEMS.find(m => m.id === 'cb-nitro-creamy') || MENU_ITEMS[4];
      }
    } else if (milk === 'black') {
      if (flavor === 'fruity') {
        matched = MENU_ITEMS.find(m => m.id === 'po-ethiopia-geisha') || MENU_ITEMS[7];
      } else {
        matched = MENU_ITEMS.find(m => m.id === 'po-colombia-pink-bourbon') || MENU_ITEMS[8];
      }
    } else if (milk === 'sweet') {
      matched = MENU_ITEMS.find(m => m.id === 'sig-spanish-pistachio') || MENU_ITEMS[2];
    } else {
      // milk
      if (flavor === 'botanical') {
        matched = MENU_ITEMS.find(m => m.id === 'sig-honey-lavender') || MENU_ITEMS[0];
      } else if (flavor === 'rich') {
        matched = MENU_ITEMS.find(m => m.id === 'esp-flat-white') || MENU_ITEMS[4];
      } else {
        matched = MENU_ITEMS.find(m => m.id === 'sig-smoked-vanilla') || MENU_ITEMS[1];
      }
    }

    setRecommendedDrink(matched || MENU_ITEMS[0]);
  };

  const resetQuiz = () => {
    setCurrentStep(0);
    setAnswers({});
    setRecommendedDrink(null);
  };

  const handleClose = () => {
    setIsQuizOpen(false);
    resetQuiz();
  };

  const currentQ = COFFEE_QUIZ_QUESTIONS[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-[#faf6f0] text-[#2b1f17] rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-[#dbc6b2] relative animate-scaleIn"
        onClick={e => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={handleClose}
          aria-label="Close Quiz"
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#ebe0d4] text-[#4d3627] flex items-center justify-center hover:bg-[#decfc0] transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* If recommended result exists */}
        {recommendedDrink ? (
          <div className="text-center space-y-6">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#2a9d8f]/15 text-[#1b7268] text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#2a9d8f]" /> 99% Taste Match Found
            </div>

            <h3 className="font-serif-coffee text-2xl sm:text-3xl font-bold text-[#1f140e]">
              Meet Your Perfect Cup
            </h3>

            {/* Drink Recommendation Card */}
            <div className="bg-white rounded-2xl overflow-hidden border border-[#ebdacf] shadow-md text-left">
              <div className="h-44 overflow-hidden relative">
                <img
                  src={recommendedDrink.image}
                  alt={recommendedDrink.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3 bg-[#1e130c]/90 text-[#fbf7f2] font-bold px-3 py-1 rounded-lg text-sm shadow">
                  ${recommendedDrink.price.toFixed(2)}
                </div>
              </div>

              <div className="p-5 space-y-3">
                <h4 className="font-serif-coffee text-xl font-bold text-[#1e130c]">
                  {recommendedDrink.name}
                </h4>
                <p className="text-xs text-[#6e5849] leading-relaxed">
                  {recommendedDrink.description}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {recommendedDrink.flavorNotes.map((n, i) => (
                    <span key={i} className="text-[11px] px-2.5 py-1 rounded-md bg-[#f7efe6] text-[#71553f] font-medium border border-[#ebdacf]">
                      {n}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => {
                  addToCart(recommendedDrink);
                  handleClose();
                }}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#9d6b38] to-[#7d4e2d] hover:from-[#af773f] hover:to-[#8c5732] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg transition"
              >
                <Coffee className="w-4 h-4" />
                <span>Add Recommended Cup to Order</span>
              </button>

              {recommendedDrink.customizable && (
                <button
                  onClick={() => {
                    handleClose();
                    openCustomizer(recommendedDrink);
                  }}
                  className="w-full py-2.5 rounded-xl border border-[#c2aa95] text-[#735845] hover:bg-[#f0e4d7] font-semibold text-xs transition"
                >
                  Customize Milk, Size, & Sweetness
                </button>
              )}

              <button
                onClick={resetQuiz}
                className="inline-flex items-center gap-1.5 text-xs text-[#8c7462] hover:text-[#2b1f17] pt-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake Quiz</span>
              </button>
            </div>
          </div>
        ) : (
          /* Active Question Screen */
          <div className="space-y-6">
            {/* Header info */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-[#8c7462] mb-1">
                <span>Coffee Palate Profiler</span>
                <span>Question {currentStep + 1} of {COFFEE_QUIZ_QUESTIONS.length}</span>
              </div>
              <div className="w-full bg-[#ebdccf] h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-[#9d6b38] h-full transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / COFFEE_QUIZ_QUESTIONS.length) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <h3 className="font-serif-coffee text-xl sm:text-2xl font-bold text-[#1f140e]">
                {currentQ.title}
              </h3>
              <p className="text-xs text-[#735845] mt-1">
                Choose the option that resonates most with your morning ritual.
              </p>
            </div>

            {/* Options list */}
            <div className="space-y-2.5">
              {currentQ.options.map(opt => {
                const isSelected = answers[currentQ.id] === opt.value;
                return (
                  <button
                    key={opt.value}
                    onClick={() => handleSelectOption(currentQ.id, opt.value)}
                    className={`w-full p-3.5 rounded-2xl border text-left transition flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#2b1b11] text-[#fbf7f2] border-[#2b1b11] shadow-md'
                        : 'bg-white text-[#523e30] border-[#ebdacf] hover:bg-[#f6eee5]'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-bold">{opt.label}</div>
                      <div className={`text-xs mt-0.5 ${isSelected ? 'text-[#d8c3b0]' : 'text-[#856e5e]'}`}>
                        {opt.description}
                      </div>
                    </div>
                    {isSelected ? (
                      <Check className="w-4 h-4 text-[#f4a261]" />
                    ) : (
                      <ArrowRight className="w-4 h-4 text-[#a88261]" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
