import { CoffeeItem, CoffeeBean, BrewGuide, LocationInfo } from '../types';

export const MENU_ITEMS: CoffeeItem[] = [
  // Signature Specialties
  {
    id: 'sig-honey-lavender',
    name: 'Wild Honey & Lavender Latte',
    category: 'signature',
    price: 6.75,
    description: 'Double espresso infused with house-infused raw wildflower honey and culinary French lavender, crowned with velvety steamed oat milk.',
    image: 'https://images.pexels.com/photos/15801079/pexels-photo-15801079.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Best Seller', 'Oat Milk Favorite', 'Floral'],
    rating: 4.9,
    reviewsCount: 342,
    isPopular: true,
    calories: 190,
    flavorNotes: ['Wildflower Honey', 'Lavender', 'Warm Vanilla', 'Creamy Cashew'],
    customizable: true,
    caffeineMg: 145,
    roastLevel: 'Medium'
  },
  {
    id: 'sig-smoked-vanilla',
    name: 'Smoked Bourbon Vanilla Cortado',
    category: 'signature',
    price: 5.95,
    description: 'Equal parts single-origin espresso and silky textured milk with oak-smoked Madagascar bourbon vanilla reduction.',
    image: 'https://images.pexels.com/photos/2251755/pexels-photo-2251755.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Barista Pick', 'Rich & Smoky', 'Low Acid'],
    rating: 4.95,
    reviewsCount: 215,
    isPopular: true,
    calories: 110,
    flavorNotes: ['Oak Wood', 'Vanilla Bean', 'Dark Cacao', 'Brown Sugar'],
    customizable: true,
    caffeineMg: 150,
    roastLevel: 'Medium-Light' as any
  },
  {
    id: 'sig-spanish-pistachio',
    name: 'Spanish Pistachio Cloud Cream',
    category: 'signature',
    price: 7.25,
    description: 'Slow-steeped nitro cold brew layered with housemade Sicilian pistachio cream foam and a sprinkle of crushed sea-salt pistachios.',
    image: 'https://images.pexels.com/photos/4869332/pexels-photo-4869332.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Seasonal Drop', 'Cold Foam', 'Decadent'],
    rating: 4.88,
    reviewsCount: 189,
    isNew: true,
    calories: 220,
    flavorNotes: ['Roasted Pistachio', 'Sweet Cream', 'Dark Chocolate', 'Sea Salt'],
    customizable: true,
    caffeineMg: 195,
  },
  {
    id: 'sig-cardamom-rose',
    name: 'Cardamom & Rose Gold Cappuccino',
    category: 'signature',
    price: 6.50,
    description: 'Hand-ground green cardamom pod infusion, double ristretto espresso, silky microfoam dusted with organic edible rose petals.',
    image: 'https://images.pexels.com/photos/6205629/pexels-photo-6205629.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Aromatic', 'Artisanal', 'Middle Eastern Spice'],
    rating: 4.85,
    reviewsCount: 128,
    calories: 140,
    flavorNotes: ['Green Cardamom', 'Sweet Brioche', 'Rosewater', 'Almond'],
    customizable: true,
    caffeineMg: 150,
  },

  // Espresso Classics
  {
    id: 'esp-flat-white',
    name: 'Velvet Flat White',
    category: 'espresso',
    price: 5.25,
    description: 'Two precision-pulled ristretto shots integrated seamlessly with glossed, micro-textured whole milk. Dense and velvet smooth.',
    image: 'https://images.pexels.com/photos/5461657/pexels-photo-5461657.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Classic', 'High Caffeine', 'Zero Sugar'],
    rating: 4.92,
    reviewsCount: 460,
    isPopular: true,
    calories: 130,
    flavorNotes: ['Milk Chocolate', 'Toasted Hazelnut', 'Caramelized Sugar'],
    customizable: true,
    caffeineMg: 160,
    roastLevel: 'Medium'
  },
  {
    id: 'esp-latte-artisan',
    name: 'Artisan Caffe Latte',
    category: 'espresso',
    price: 5.50,
    description: 'Rich espresso balanced with generous steamed milk and light, silky micro-foam with hand-poured seasonal rosetta art.',
    image: 'https://images.pexels.com/photos/36946473/pexels-photo-36946473.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Classic Comfort', 'Customizable'],
    rating: 4.87,
    reviewsCount: 520,
    calories: 180,
    flavorNotes: ['Creamy Praline', 'Sweet Cocoa', 'Biscuit'],
    customizable: true,
    caffeineMg: 150,
    roastLevel: 'Medium'
  },
  {
    id: 'esp-cortado-classic',
    name: 'Traditional Spanish Cortado',
    category: 'espresso',
    price: 4.85,
    description: '1:1 ratio of intense double espresso and warm lightly textured milk, served in a traditional Gibraltar glass.',
    image: 'https://images.pexels.com/photos/39475008/pexels-photo-39475008.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Barista Pick', 'Bold Espresso'],
    rating: 4.94,
    reviewsCount: 310,
    calories: 75,
    flavorNotes: ['Dark Chocolate Truffle', 'Molasses', 'Walnut'],
    customizable: true,
    caffeineMg: 155,
    roastLevel: 'Dark'
  },
  {
    id: 'esp-americano',
    name: 'Caffe Americano (Single Origin)',
    category: 'espresso',
    price: 4.25,
    description: 'Double espresso elongated with 200°F pure filtered mountain water, preserving delicate floral crema and crisp clarity.',
    image: 'https://images.pexels.com/photos/35667656/pexels-photo-35667656.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Clean', 'Zero Calorie', 'Keto Friendly'],
    rating: 4.82,
    reviewsCount: 198,
    calories: 5,
    flavorNotes: ['Black Cherry', 'Cacao Nibs', 'Toasted Graham'],
    customizable: true,
    caffeineMg: 165,
    roastLevel: 'Medium'
  },

  // Cold Brew & Refreshers
  {
    id: 'cb-nitro-creamy',
    name: '24-Hour Nitro Draft Cold Brew',
    category: 'cold-brew',
    price: 5.95,
    description: 'Slow-steeped for 24 hours in ice-cold microfiltered water and nitrogen-infused on tap for a Guinness-like cascade and naturally sweet, creamy mouthfeel.',
    image: 'https://images.pexels.com/photos/33241858/pexels-photo-33241858.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Nitro On Tap', 'Super Smooth', 'No Sugar Needed'],
    rating: 4.96,
    reviewsCount: 540,
    isPopular: true,
    calories: 10,
    flavorNotes: ['Dark Chocolate Fudge', 'Blueberry', 'Brown Sugar Sweetness'],
    customizable: true,
    caffeineMg: 220,
    roastLevel: 'Medium'
  },
  {
    id: 'cb-caramel-cloud',
    name: 'Salted Caramel Cream Cold Brew',
    category: 'cold-brew',
    price: 6.85,
    description: 'Signature cold brew sweetened with handcrafted vanilla syrup, layered with thick salted caramel cold foam and Maldon flakes.',
    image: 'https://images.pexels.com/photos/36873340/pexels-photo-36873340.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Top Rated', 'Sweet & Savory', 'Cold Foam'],
    rating: 4.93,
    reviewsCount: 420,
    isPopular: true,
    calories: 210,
    flavorNotes: ['Buttery Caramel', 'Flaky Sea Salt', 'Cold Brew Cocoa'],
    customizable: true,
    caffeineMg: 185,
  },
  {
    id: 'cb-tonic-citrus',
    name: 'Espresso Citrus Spritz & Tonic',
    category: 'cold-brew',
    price: 6.25,
    description: 'Double shot of Ethiopian espresso poured over artisanal Indian tonic water, fresh blood orange slice, and a bruised sprig of rosemary on ice.',
    image: 'https://images.pexels.com/photos/13735966/pexels-photo-13735966.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Sparkling', 'Refreshing', 'Citrus & Herb'],
    rating: 4.79,
    reviewsCount: 140,
    isNew: true,
    calories: 60,
    flavorNotes: ['Bergamot Citrus', 'Sparkling Quinine', 'Floral Jasmine', 'Rosemary'],
    customizable: true,
    caffeineMg: 150,
  },

  // Pour Over & Single Origins
  {
    id: 'po-ethiopia-geisha',
    name: 'Ethiopia Yirgacheffe G1 Reserve (V60)',
    category: 'pour-over',
    price: 7.50,
    description: 'Precision hand pour-over brewed at 1:16 ratio. High altitude natural process bean bursting with aromatic white florals, peach, and lemon candy.',
    image: 'https://images.pexels.com/photos/31986822/pexels-photo-31986822.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Single Origin 2026', 'Natural Process', 'Artisan Cup'],
    rating: 4.98,
    reviewsCount: 380,
    isPopular: true,
    calories: 5,
    flavorNotes: ['Jasmine Flower', 'White Peach', 'Bergamot', 'Meyer Lemon'],
    customizable: false,
    caffeineMg: 175,
    roastLevel: 'Light',
    origin: 'Yirgacheffe, Ethiopia • 2,100m'
  },
  {
    id: 'po-colombia-pink-bourbon',
    name: 'Colombia Huila Pink Bourbon (Chemex)',
    category: 'pour-over',
    price: 7.20,
    description: 'Rare Pink Bourbon varietal offering bright juicy acidity, candied watermelon notes, and a silky sugarcane honey finish.',
    image: 'https://images.pexels.com/photos/27077141/pexels-photo-27077141.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Direct Trade', 'Rare Varietal', 'Light Roast'],
    rating: 4.91,
    reviewsCount: 210,
    calories: 5,
    flavorNotes: ['Pink Guava', 'Watermelon Candy', 'Sugarcane', 'Lime Zest'],
    customizable: false,
    caffeineMg: 170,
    roastLevel: 'Light',
    origin: 'Huila, Colombia • 1,950m'
  },
  {
    id: 'po-guatemala-antigua',
    name: 'Guatemala Antigua Volcano Peaberry (Kalita)',
    category: 'pour-over',
    price: 6.90,
    description: 'Grown on mineral-rich volcanic slopes. Full-bodied with dense dark cocoa, spiced roasted plum, and warm cinnamon aromatics.',
    image: 'https://images.pexels.com/photos/31986825/pexels-photo-31986825.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Volcanic Soil', 'Rich Body', 'Washed Process'],
    rating: 4.86,
    reviewsCount: 165,
    calories: 5,
    flavorNotes: ['Dark Cocoa', 'Roasted Plum', 'Nutmeg', 'Toffee'],
    customizable: false,
    caffeineMg: 165,
    roastLevel: 'Medium',
    origin: 'Antigua, Guatemala • 1,700m'
  },

  // Bakery & Toast
  {
    id: 'bak-butter-croissant',
    name: 'Golden French Butter Croissant',
    category: 'bakery',
    price: 4.75,
    description: 'Baked fresh every morning with Normandy butter. 72 paper-thin flaky layers with a honeycomb interior and caramelized golden crisp exterior.',
    image: 'https://images.pexels.com/photos/3914060/pexels-photo-3914060.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Baked Fresh 6 AM', 'Classic French', 'Pairs with Cappuccino'],
    rating: 4.94,
    reviewsCount: 680,
    isPopular: true,
    calories: 310,
    flavorNotes: ['Cultured Butter', 'Toasted Wheat', 'Caramelized Honey'],
    customizable: false,
  },
  {
    id: 'bak-almond-pain-choc',
    name: 'Almond & Valrhona Chocolate Swirl',
    category: 'bakery',
    price: 5.65,
    description: 'Twice-baked croissant stuffed with almond frangipane cream, semi-sweet Valrhona 64% chocolate batons, and toasted sliced almonds.',
    image: 'https://images.pexels.com/photos/33188113/pexels-photo-33188113.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Decadent', 'Best with Espresso'],
    rating: 4.97,
    reviewsCount: 390,
    isPopular: true,
    calories: 420,
    flavorNotes: ['Almond Cream', 'Dark Valrhona', 'Flaky Brioche'],
    customizable: false,
  },
  {
    id: 'bak-sourdough-avocado',
    name: 'Artisan Country Sourdough Toast & Ricotta',
    category: 'bakery',
    price: 9.50,
    description: 'Thick toasted organic sourdough, whipped lemon ricotta, crushed Hass avocado, pickled shallots, microgreens, and Aleppo chili oil.',
    image: 'https://images.pexels.com/photos/14630368/pexels-photo-14630368.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    tags: ['Breakfast Favorite', 'Vegetarian', 'Savory'],
    rating: 4.89,
    reviewsCount: 275,
    calories: 380,
    flavorNotes: ['Crisp Sourdough', 'Creamy Lemon Ricotta', 'Aleppo Crunch'],
    customizable: false,
  }
];

export const COFFEE_BEANS: CoffeeBean[] = [
  {
    id: 'bean-ethiopia-g1',
    name: 'Yirgacheffe Misty Valley G1',
    origin: 'Gedeo Zone, Ethiopia',
    altitude: '1,950m – 2,200m',
    process: 'Natural Sun-Dried on Raised Beds',
    roastLevel: 'Light Roast',
    tastingNotes: ['Meyer Lemon', 'Wild Jasmine', 'Peach Nectar', 'Raw Honey'],
    price: 21.00,
    image: 'https://images.pexels.com/photos/37216771/pexels-photo-37216771.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    rating: 4.98,
    bagSize: '340g / 12 oz (Whole Bean or Custom Grind)',
    description: 'An ethereal cup bursting with radiant jasmine aroma and sparkling stone-fruit acidity. Hand-sorted at pinnacle ripeness.'
  },
  {
    id: 'bean-house-velvet',
    name: 'Terra Signature Espresso Blend',
    origin: 'Colombia Huila + Brazil Cerrado',
    altitude: '1,200m – 1,800m',
    process: 'Washed & Natural Blend',
    roastLevel: 'Medium',
    tastingNotes: ['Dark Chocolate Fudge', 'Toasted Hazelnut', 'Caramel Crema'],
    price: 18.50,
    image: 'https://images.pexels.com/photos/31435390/pexels-photo-31435390.png?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    rating: 4.95,
    bagSize: '340g / 12 oz (Whole Bean or Custom Grind)',
    description: 'The heartbeat of our cafe. Formulated for heavy body, rich chocolate richness, and an opulent crema that shines with milk.'
  },
  {
    id: 'bean-colombia-san-agustin',
    name: 'San Agustín Supremo Reserve',
    origin: 'Huila, Colombia',
    altitude: '1,750m',
    process: 'Fully Washed, Mountain Spring Water',
    roastLevel: 'Medium-Light',
    tastingNotes: ['Red Apple Crisp', 'Brown Cane Sugar', 'Orange Marmalade'],
    price: 19.50,
    image: 'https://images.pexels.com/photos/33241858/pexels-photo-33241858.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    rating: 4.9,
    bagSize: '340g / 12 oz (Whole Bean or Custom Grind)',
    description: 'A benchmark Colombian profile. Clean, vibrant sweetness with comforting warmth and balanced acidity suitable for any brew method.'
  },
  {
    id: 'bean-sumatra-mandheling',
    name: 'Sumatra Lake Toba Triple-Picked',
    origin: 'Aceh Highlands, Sumatra',
    altitude: '1,500m',
    process: 'Wet-Hulled (Giling Basah)',
    roastLevel: 'Dark Roast',
    tastingNotes: ['Cedar & Tobacco Leaf', 'Baker\'s Cocoa', 'Molasses', 'Earthy Spice'],
    price: 20.00,
    image: 'https://images.pexels.com/photos/37216771/pexels-photo-37216771.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    rating: 4.87,
    bagSize: '340g / 12 oz (Whole Bean or Custom Grind)',
    description: 'For lovers of deep, smoky complexity and syrupy body. Ultra low acid with deep forest aromatics and sweet molasses finish.'
  }
];

export const BREW_GUIDES: BrewGuide[] = [
  {
    id: 'v60',
    name: 'Hario V60 Pour Over',
    ratio: '1:16 (1g coffee to 16g water)',
    ratioMultiplier: 16,
    grindSize: 'Medium-Fine (like sea salt)',
    waterTemp: '202°F / 94°C',
    brewTime: '3:00 - 3:30 min',
    idealDose: 18,
    difficulty: 'Moderate',
    description: 'The golden standard of specialty coffee. Delivers crisp clarity, vibrant acidity, and allows delicate floral nuances to sing.',
    icon: 'Coffee',
    steps: [
      { name: 'Rinse Filter', timeSec: 20, waterAmountGrams: 0, instruction: 'Rinse paper filter with hot water to remove paper taste and pre-heat the dripper and server. Discard rinse water.' },
      { name: 'The Bloom', timeSec: 45, waterAmountGrams: 50, instruction: 'Gently pour 50g of water over dry coffee grounds in concentric spirals. Let it bloom for 45s to release trapped CO₂.' },
      { name: 'First Continuous Pour', timeSec: 50, waterAmountGrams: 150, instruction: 'Pour steadily in outward spirals up to 200g. Keep kettle spout close to avoid excessive turbulence.' },
      { name: 'Final Pour & Drawdown', timeSec: 65, waterAmountGrams: 100, instruction: 'Pour remaining water up to total weight. Give a gentle swirl around the rim to flatten the coffee bed and allow full drawdown.' }
    ]
  },
  {
    id: 'french-press',
    name: 'French Press (Immersion)',
    ratio: '1:15 (1g coffee to 15g water)',
    ratioMultiplier: 15,
    grindSize: 'Coarse (like breadcrumbs)',
    waterTemp: '205°F / 96°C',
    brewTime: '4:30 min',
    idealDose: 30,
    difficulty: 'Easy',
    description: 'Full immersion brewing that extracts essential coffee oils. Rich, velvety, and deeply satisfying body with zero paper filter absorption.',
    icon: 'Feather',
    steps: [
      { name: 'Add Grounds & Pre-heat', timeSec: 15, waterAmountGrams: 0, instruction: 'Add coarse coffee grounds into the pre-warmed glass carafe.' },
      { name: 'Initial Fill', timeSec: 45, waterAmountGrams: 450, instruction: 'Pour all calculated water fast and evenly to ensure all grounds are fully saturated.' },
      { name: 'The Crust Steep', timeSec: 180, waterAmountGrams: 0, instruction: 'Place plunger lid on top without depressing. Allow the coffee crust to steep untouched for 3 full minutes.' },
      { name: 'Break Crust & Press', timeSec: 30, waterAmountGrams: 0, instruction: 'Using two spoons, stir crust gently, skim off white foam, then slowly press down the metal plunger.' }
    ]
  },
  {
    id: 'aeropress',
    name: 'AeroPress (Inverted Method)',
    ratio: '1:12 (Intense Espresso-Style)',
    ratioMultiplier: 12,
    grindSize: 'Fine-Medium (like table salt)',
    waterTemp: '190°F / 88°C',
    brewTime: '2:00 min',
    idealDose: 16,
    difficulty: 'Moderate',
    description: 'Invented by an aerodynamics engineer. Uses gentle air pressure to extract sweet, zero-bitterness concentrate with rich crema.',
    icon: 'Zap',
    steps: [
      { name: 'Setup Inverted', timeSec: 15, waterAmountGrams: 0, instruction: 'Set AeroPress upside down with plunger at the #4 mark. Pre-wet paper filter in cap.' },
      { name: 'Pour Water', timeSec: 30, waterAmountGrams: 192, instruction: 'Pour hot water vigorously over coffee. Stir grounds thoroughly with paddle for 10 seconds.' },
      { name: 'Cap & Wait', timeSec: 45, waterAmountGrams: 0, instruction: 'Lock the filter cap in place. Let steep for 45 seconds.' },
      { name: 'Flip & Gentle Press', timeSec: 30, waterAmountGrams: 0, instruction: 'Carefully flip onto sturdy mug. Press plunger smoothly downward until you hear the hiss of air.' }
    ]
  },
  {
    id: 'cold-brew',
    name: 'Slow Immersion Cold Brew',
    ratio: '1:8 (Concentrate)',
    ratioMultiplier: 8,
    grindSize: 'Extra Coarse (like kosher salt)',
    waterTemp: 'Cold / Room Temp Pure Water',
    brewTime: '18 - 24 Hours',
    idealDose: 60,
    difficulty: 'Easy',
    description: 'Slow cold extraction that virtually eliminates stomach acidity. Yields a rich syrup-like concentrate perfect over ice or with creamy oat milk.',
    icon: 'Snowflake',
    steps: [
      { name: 'Combine Grounds & Cold Water', timeSec: 60, waterAmountGrams: 480, instruction: 'Combine coarsely ground coffee with room-temperature filtered water in a mason jar or cold brewer.' },
      { name: 'Submerge & Stir', timeSec: 30, waterAmountGrams: 0, instruction: 'Ensure every coffee ground is fully submerged under water with a wooden spoon.' },
      { name: 'Cold Steep', timeSec: 60, waterAmountGrams: 0, instruction: 'Seal tightly and let rest in the refrigerator or cool pantry for 18 to 24 hours.' },
      { name: 'Double Strain', timeSec: 60, waterAmountGrams: 0, instruction: 'Filter through cheesecloth or a V60 paper filter for sparkling crystal-clean cold brew concentrate.' }
    ]
  }
];

export const CAFE_LOCATIONS: LocationInfo[] = [
  {
    id: 'loc-downtown',
    name: 'Flagship Roastery & Cafe',
    address: '428 Timber & Stone Way',
    city: 'Downtown Arts District, Portland OR',
    hours: 'Mon - Sun: 7:00 AM – 8:00 PM',
    phone: '(503) 555-0198',
    status: 'Open Now',
    features: ['In-House Roaster', 'Outdoor Heated Patio', 'High-Speed Wi-Fi', 'Pour-Over Bar', 'Dog Friendly']
  },
  {
    id: 'loc-uptown',
    name: 'The Greenhouse Espresso Bar',
    address: '812 Botanical Grove Ave',
    city: 'Uptown Historic Quarter, Portland OR',
    hours: 'Mon - Sun: 7:30 AM – 6:30 PM',
    phone: '(503) 555-0244',
    status: 'Open Now',
    features: ['Sunlit Atrium', 'Artisan Bakery Oven', 'Curated Vinyl Listening Corner', 'Takeout Window']
  }
];

export const REVIEWS = [
  {
    id: 'rev-1',
    author: 'Elena Vance',
    role: 'Specialty Coffee Guild Member',
    avatar: 'https://images.pexels.com/photos/15801079/pexels-photo-15801079.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=120',
    rating: 5,
    date: 'Yesterday',
    drink: 'Wild Honey & Lavender Latte',
    comment: 'The honey lavender latte is honestly transcendent. The French lavender isn\'t perfumey at all—it balances with their house roast like poetry. Their baristas take hospitality to another level.'
  },
  {
    id: 'rev-2',
    author: 'Marcus Sterling',
    role: 'Home Brewer & Architect',
    avatar: 'https://images.pexels.com/photos/2251755/pexels-photo-2251755.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=120',
    rating: 5,
    date: '3 days ago',
    drink: 'Ethiopia Yirgacheffe V60',
    comment: 'The clarity on the Yirgacheffe pour-over blew me away. You can distinctively taste the fresh white peach and jasmine. The brew guide calculator on their website made my home cups 10x better too!'
  },
  {
    id: 'rev-3',
    author: 'Chloe Dupont',
    role: 'Food & Lifestyle Writer',
    avatar: 'https://images.pexels.com/photos/5461657/pexels-photo-5461657.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=120&w=120',
    rating: 5,
    date: '1 week ago',
    drink: 'French Butter Croissant & Nitro Cold Brew',
    comment: 'The 72-layer croissant paired with the 24-hr nitro draft is my Saturday morning ritual. Warm, inviting atmosphere, vinyl music playing softly—it\'s the best coffee house in town.'
  }
];

export const COFFEE_QUIZ_QUESTIONS = [
  {
    id: 'milk_preference',
    title: 'How do you like your coffee served?',
    options: [
      { label: 'Black & Pure', description: 'Maximum terroir clarity, no dairy or sugar', value: 'black' },
      { label: 'Silky Milk & Microfoam', description: 'Velvety lattes, flat whites, cappuccinos', value: 'milk' },
      { label: 'Iced & Cold Brew', description: 'Chilled, refreshing, crisp on hot afternoons', value: 'iced' },
      { label: 'Sweet & Creamy Dessert', description: 'Caramel clouds, flavored infusions, cold foams', value: 'sweet' }
    ]
  },
  {
    id: 'flavor_profile',
    title: 'What flavors make you smile?',
    options: [
      { label: 'Dark Chocolate & Warm Caramel', description: 'Rich, comforting, deep nutty tones', value: 'rich' },
      { label: 'Bright Fruit & Jasmine Flowers', description: 'Juicy, sparkling citrus, delicate tea-like', value: 'fruity' },
      { label: 'Spiced & Botanical Herb', description: 'Cardamom, cinnamon, lavender, vanilla', value: 'botanical' },
      { label: 'Sweet Cream & Roasted Nut', description: 'Pistachio cream, salted honey, hazelnut', value: 'nutty' }
    ]
  },
  {
    id: 'caffeine_vibe',
    title: 'What\'s your preferred energy boost?',
    options: [
      { label: 'High Octane Wake-Up', description: 'Double shot or cold brew kick', value: 'high' },
      { label: 'Balanced & Mindful Sip', description: 'Single cortado or smooth pour-over', value: 'medium' },
      { label: 'Cozy Afternoon Leisure', description: 'Gentle milk drink or decaf delight', value: 'low' }
    ]
  }
];
